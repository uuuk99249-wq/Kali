#!/usr/bin/env sh
set -eu
if command -v ./gradlew >/dev/null 2>&1 && [ -f ./gradlew ]; then
  ./gradlew --no-daemon assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle --no-daemon assembleDebug
else
  echo "Gradle was not found. Open this project in an Android IDE with Gradle support, or install/configure Gradle 8.9 and Java 17." >&2
  exit 1
fi
echo "APK output: app/build/outputs/apk/debug/app-debug.apk"
