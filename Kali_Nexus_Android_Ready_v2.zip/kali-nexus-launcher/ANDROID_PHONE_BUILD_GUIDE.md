# KALI NEXUS — Build on an Android phone

This project is a native Kotlin + Jetpack Compose Android app. It is not a website.

## Important

This prepared package is still source code, not an APK. It has not been compiled in this environment. A successful build must be verified before installing it.

## Recommended phone workflow: AndroidIDE

1. Install AndroidIDE only from its official project/site: https://m.androidide.com/ . Check the current release notes and Android-version compatibility first.
2. Extract this ZIP using your file manager into a folder such as `Download/kali-nexus-launcher`.
3. In AndroidIDE, open/import the extracted `kali-nexus-launcher` project folder (the folder containing `settings.gradle.kts`). Do not open the outer ZIP.
4. Allow the IDE to install/configure its JDK and Android SDK components if prompted. This project requires Java 17, Android SDK Platform 35, and Build Tools 35.0.0.
5. Allow Gradle to sync. The project uses Android Gradle Plugin 8.7.3 and Gradle 8.9.
6. If the IDE offers a terminal with Gradle installed, run from the project root:

   `gradle --version`

   Then build:

   `gradle --no-daemon assembleDebug`

7. The debug APK should appear at:

   `app/build/outputs/apk/debug/app-debug.apk`

8. Install that APK. Android may ask you to allow installs from the app you used to open it.

## If Gradle sync/build fails

- First check that the IDE supports Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.0.21, and Java 17.
- Ensure SDK Platform 35 and Build Tools 35.0.0 are installed.
- Ensure there is enough free storage and memory; close other apps before building.
- Copy the first actual error and the 20–40 lines around it. Do not randomly change dependency versions.

## Wrapper note

The original project includes `gradle/wrapper/gradle-wrapper.properties` but does not include `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`. If the IDE requires the wrapper, use its Gradle installation/terminal to generate it from the project root:

`gradle wrapper --gradle-version 8.9`

Then retry the build using `./gradlew assembleDebug` if the environment supports shell scripts.

## Device compatibility

The app declares minSdk 29 (Android 10). Device-specific support for building inside AndroidIDE varies. If the IDE cannot support this project's plugin/toolchain combination, use a trusted cloud Android build service or a desktop Android Studio environment rather than downgrading random dependencies.
