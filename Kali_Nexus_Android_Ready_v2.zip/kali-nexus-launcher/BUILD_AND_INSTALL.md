# Building & Installing the KALI NEXUS APK

## Prerequisites

- **Android Studio**: Ladybug (2024.2.1) or newer
- **JDK**: Java 17 (bundled with Android Studio as JetBrains Runtime)
- **Android SDK**: Platform API 35 (`compileSdk = 35`), Build-Tools 35.0.0, Minimum target device Android 10 (API 29+)

## Option A: Build & Run via Android Studio (Recommended)

1. Open Android Studio and choose **File → Open**.
2. Select the `kali-nexus-launcher` folder.
3. Wait for Gradle Sync to download dependencies (`libs.versions.toml` + `gradle-wrapper.properties`).
4. Connect an Android 10+ phone with **USB Debugging** enabled (or launch an API 29–35 Emulator).
5. Click **Run (`Shift+F10`)**.

## Option B: Build Debug or Release APK via Command Line

From inside `kali-nexus-launcher/`:

```bash
# If Gradle is installed globally or after generating the wrapper jar in Android Studio:
gradle wrapper --gradle-version 8.9

# Build Debug APK
./gradlew assembleDebug

# Output location:
# app/build/outputs/apk/debug/app-debug.apk

# Build Minified Release APK (configure signingConfig in app/build.gradle.kts for release distribution)
./gradlew assembleRelease
```

## Installing via ADB

```bash
adb devices
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Setting KALI NEXUS as Default Home Launcher

1. Launch **KALI NEXUS** from your existing launcher or press the **Home** button.
2. Tap **Set Default** on the Home banner (or open **SETTINGS → Set as Default Launcher**).
3. On Android 10+, the system `RoleManager` dialog will prompt you to choose **KALI NEXUS** as your Home app.
4. Alternatively, open **Android Settings → Apps → Default apps → Home app** and select **KALI NEXUS**.
