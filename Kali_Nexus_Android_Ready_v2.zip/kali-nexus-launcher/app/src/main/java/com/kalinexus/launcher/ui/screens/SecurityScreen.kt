package com.kalinexus.launcher.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.VpnKey
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.kalinexus.launcher.ui.components.CyberSurfaceCard
import com.kalinexus.launcher.ui.components.SectionHeader
import com.kalinexus.launcher.ui.theme.LocalKaliPalette
import com.kalinexus.launcher.viewmodel.LauncherUiState

@Composable
fun SecurityScreen(
    state: LauncherUiState,
    onOpenSecuritySettings: () -> Unit,
    onSetDefaultHome: () -> Unit,
    onOpenUsageAccess: () -> Unit,
    onOpenAppInfo: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current
    val sec = state.securityOverview

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Security Posture",
                subtitle = "NON-ROOT PLATFORM AUDIT & ACCESS CONTROLS"
            )
        }

        item {
            CyberSurfaceCard(highlightBorder = true) {
                Text(
                    text = "ACTIVE PLATFORM CHECKS",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent
                )
                Spacer(modifier = Modifier.height(10.dp))

                SecurityCheckRow(
                    icon = if (sec.isDeviceLockSecure) Icons.Outlined.Lock else Icons.Outlined.LockOpen,
                    title = "Device Screen Lock",
                    status = if (sec.isDeviceLockSecure) "PIN / Biometric Active" else "Unprotected",
                    isNominal = sec.isDeviceLockSecure,
                    actionLabel = "Configure",
                    onAction = onOpenSecuritySettings
                )
                HorizontalDivider(color = palette.hairlineBorder)

                SecurityCheckRow(
                    icon = Icons.Outlined.Shield,
                    title = "Default Home Launcher",
                    status = if (sec.isDefaultHomeLauncher) "KALI NEXUS Active" else "Not Default",
                    isNominal = sec.isDefaultHomeLauncher,
                    actionLabel = if (sec.isDefaultHomeLauncher) "Manage" else "Set Default",
                    onAction = onSetDefaultHome
                )
                HorizontalDivider(color = palette.hairlineBorder)

                SecurityCheckRow(
                    icon = Icons.Outlined.VpnKey,
                    title = "VPN Transport Tunnel",
                    status = if (sec.isVpnActive) "Active VPN Detected" else "Direct Network",
                    isNominal = sec.isVpnActive,
                    actionLabel = "System",
                    onAction = onOpenSecuritySettings
                )
                HorizontalDivider(color = palette.hairlineBorder)

                SecurityCheckRow(
                    icon = Icons.Outlined.Shield,
                    title = "Usage Stats Access",
                    status = if (sec.hasUsageStatsPermission) "Granted (Recent Apps)" else "Not Granted",
                    isNominal = sec.hasUsageStatsPermission,
                    actionLabel = "Permissions",
                    onAction = onOpenUsageAccess
                )
            }
        }

        item {
            CyberSurfaceCard {
                Text(
                    text = "PACKAGE INVENTORY (${sec.userInstalledAppsCount} USER / ${sec.totalInstalledLaunchableApps} TOTAL)",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Recently installed or updated user applications. Tap any package to inspect Android system permissions.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary
                )
            }
        }

        items(sec.recentlyInstalledApps, key = { it.packageName }) { app ->
            CyberSurfaceCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onOpenAppInfo(app.packageName) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = app.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary
                        )
                        Text(
                            text = app.packageName,
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textMuted
                        )
                    }
                    Text(
                        text = "Inspect",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.primaryAccent
                    )
                }
            }
        }

        item {
            CyberSurfaceCard {
                Text(
                    text = "FUTURE MODULES (ROADMAP PLACEHOLDERS)",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.warningAmber
                )
                Spacer(modifier = Modifier.height(8.dp))
                PlannedModuleItem(
                    title = "[PLANNED MODULE] Per-App Permission Risk Matrix",
                    detail = "Deep manifest permission classification across camera, mic, and location scopes."
                )
                Spacer(modifier = Modifier.height(6.dp))
                PlannedModuleItem(
                    title = "[PLANNED MODULE] Local VPN DNS & Packet Telemetry",
                    detail = "Android VpnService-based non-root domain inspection dashboard."
                )
                Spacer(modifier = Modifier.height(6.dp))
                PlannedModuleItem(
                    title = "[PLANNED MODULE] Biometric App Vault",
                    detail = "BiometricPrompt lock gate for launching sensitive hidden utilities."
                )
            }
        }
    }
}

@Composable
private fun SecurityCheckRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    status: String,
    isNominal: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    val palette = LocalKaliPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isNominal) palette.nominalGreen else palette.warningAmber,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                Text(
                    status,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isNominal) palette.nominalGreen else palette.warningAmber
                )
            }
        }
        TextButton(onClick = onAction) {
            Text(actionLabel, color = palette.primaryAccent)
        }
    }
}

@Composable
private fun PlannedModuleItem(title: String, detail: String) {
    val palette = LocalKaliPalette.current
    Column {
        Text(title, style = MaterialTheme.typography.labelMedium, color = palette.textPrimary)
        Text(detail, style = MaterialTheme.typography.bodyMedium, color = palette.textMuted)
    }
}
