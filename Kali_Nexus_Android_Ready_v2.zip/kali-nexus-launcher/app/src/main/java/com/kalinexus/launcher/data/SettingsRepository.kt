package com.kalinexus.launcher.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.kalinexus.launcher.model.AnimationSpeed
import com.kalinexus.launcher.model.AppIconStyle
import com.kalinexus.launcher.model.AppSortOrder
import com.kalinexus.launcher.model.ClockSizePreset
import com.kalinexus.launcher.model.CyberThemePreset
import com.kalinexus.launcher.model.HomePinnedApp
import com.kalinexus.launcher.model.IconSizePreset
import com.kalinexus.launcher.model.LauncherPreferences
import com.kalinexus.launcher.model.WallpaperPreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException

private val Context.kaliNexusDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "kali_nexus_launcher_prefs"
)

class SettingsRepository(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    private object Keys {
        val PREFS_JSON = stringPreferencesKey("launcher_preferences_json")
    }

    val preferencesFlow: Flow<LauncherPreferences> = context.kaliNexusDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            val raw = prefs[Keys.PREFS_JSON]
            if (raw.isNullOrBlank()) {
                LauncherPreferences()
            } else {
                runCatching { json.decodeFromString<LauncherPreferences>(raw) }
                    .getOrDefault(LauncherPreferences())
            }
        }

    suspend fun updatePreferences(transform: (LauncherPreferences) -> LauncherPreferences) {
        context.kaliNexusDataStore.edit { prefs ->
            val currentRaw = prefs[Keys.PREFS_JSON]
            val current = if (currentRaw.isNullOrBlank()) {
                LauncherPreferences()
            } else {
                runCatching { json.decodeFromString<LauncherPreferences>(currentRaw) }
                    .getOrDefault(LauncherPreferences())
            }
            val updated = transform(current)
            prefs[Keys.PREFS_JSON] = json.encodeToString(updated)
        }
    }

    suspend fun replaceAllPreferences(newPreferences: LauncherPreferences) {
        context.kaliNexusDataStore.edit { prefs ->
            prefs[Keys.PREFS_JSON] = json.encodeToString(newPreferences)
        }
    }

    suspend fun setTheme(preset: CyberThemePreset) = updatePreferences {
        it.copy(themePreset = preset)
    }

    suspend fun setWallpaper(preset: WallpaperPreset, customUri: String? = null) = updatePreferences {
        it.copy(
            wallpaperPreset = preset,
            customWallpaperUri = customUri ?: it.customWallpaperUri
        )
    }

    suspend fun setWallpaperDim(alpha: Float) = updatePreferences {
        it.copy(wallpaperDimAlpha = alpha.coerceIn(0.1f, 0.9f))
    }

    suspend fun setIconSize(size: IconSizePreset) = updatePreferences {
        it.copy(iconSize = size)
    }

    suspend fun setIconStyle(style: AppIconStyle) = updatePreferences {
        it.copy(iconStyle = style)
    }

    suspend fun setIconPackPackage(packageName: String?) = updatePreferences {
        it.copy(selectedIconPackPackage = packageName)
    }

    suspend fun setAnimationSpeed(speed: AnimationSpeed) = updatePreferences {
        it.copy(animationSpeed = speed)
    }

    suspend fun setGridDimensions(columns: Int, rows: Int) = updatePreferences {
        it.copy(
            gridColumns = columns.coerceIn(4, 5),
            gridRows = rows.coerceIn(4, 6)
        )
    }

    suspend fun setHomePageCount(count: Int) = updatePreferences {
        val clamped = count.coerceIn(1, 5)
        it.copy(
            homePageCount = clamped,
            homePinnedApps = it.homePinnedApps.filter { pinned -> pinned.pageIndex < clamped }
        )
    }

    suspend fun setDockSettings(showDock: Boolean, dockCount: Int, showLabels: Boolean) =
        updatePreferences {
            it.copy(
                showDock = showDock,
                dockCount = dockCount.coerceIn(4, 6),
                showDockLabels = showLabels
            )
        }

    suspend fun setClockSettings(use24Hour: Boolean, showSeconds: Boolean, size: ClockSizePreset) =
        updatePreferences {
            it.copy(
                use24HourClock = use24Hour,
                showClockSeconds = showSeconds,
                clockSize = size
            )
        }

    suspend fun setWeatherSettings(
        showWidget: Boolean,
        useLive: Boolean,
        cityLabel: String,
        latitude: Double,
        longitude: Double
    ) = updatePreferences {
        it.copy(
            showWeatherWidget = showWidget,
            useLiveWeather = useLive,
            weatherCityLabel = cityLabel,
            weatherLatitude = latitude,
            weatherLongitude = longitude
        )
    }

    suspend fun setShowHomeTelemetryStrip(show: Boolean) = updatePreferences {
        it.copy(showHomeTelemetryStrip = show)
    }

    suspend fun setSearchSettings(
        showRecent: Boolean,
        autoFocus: Boolean,
        searchPackages: Boolean,
        sortOrder: AppSortOrder
    ) = updatePreferences {
        it.copy(
            showRecentApps = showRecent,
            autoFocusDrawerSearch = autoFocus,
            searchPackageNames = searchPackages,
            sortOrder = sortOrder
        )
    }

    suspend fun toggleDockPackage(packageName: String) = updatePreferences { prefs ->
        val updated = if (packageName in prefs.dockPackages) {
            prefs.dockPackages.filterNot { it == packageName }
        } else {
            (prefs.dockPackages + packageName).take(prefs.dockCount)
        }
        prefs.copy(dockPackages = updated)
    }

    suspend fun seedInitialDockIfEmpty(defaultPackages: List<String>) = updatePreferences { prefs ->
        if (prefs.dockPackages.isNotEmpty() || defaultPackages.isEmpty()) {
            prefs
        } else {
            prefs.copy(dockPackages = defaultPackages.take(prefs.dockCount))
        }
    }

    suspend fun toggleFavoritePackage(packageName: String) = updatePreferences { prefs ->
        val updated = if (packageName in prefs.favoritePackages) {
            prefs.favoritePackages - packageName
        } else {
            prefs.favoritePackages + packageName
        }
        prefs.copy(favoritePackages = updated)
    }

    suspend fun setAppHidden(packageName: String, hidden: Boolean) = updatePreferences { prefs ->
        val updatedHidden = if (hidden) {
            prefs.hiddenPackages + packageName
        } else {
            prefs.hiddenPackages - packageName
        }
        prefs.copy(
            hiddenPackages = updatedHidden,
            dockPackages = if (hidden) prefs.dockPackages.filterNot { it == packageName } else prefs.dockPackages,
            homePinnedApps = if (hidden) prefs.homePinnedApps.filterNot { it.packageName == packageName } else prefs.homePinnedApps
        )
    }

    suspend fun pinAppToHomePage(packageName: String, pageIndex: Int) = updatePreferences { prefs ->
        val exists = prefs.homePinnedApps.any {
            it.packageName == packageName && it.pageIndex == pageIndex
        }
        if (exists) {
            prefs
        } else {
            prefs.copy(homePinnedApps = prefs.homePinnedApps + HomePinnedApp(packageName, pageIndex))
        }
    }

    suspend fun unpinAppFromHomePage(packageName: String, pageIndex: Int) = updatePreferences { prefs ->
        prefs.copy(
            homePinnedApps = prefs.homePinnedApps.filterNot {
                it.packageName == packageName && it.pageIndex == pageIndex
            }
        )
    }

    suspend fun toggleGamingPackage(packageName: String) = updatePreferences { prefs ->
        val updated = if (packageName in prefs.gamingPackages) {
            prefs.gamingPackages - packageName
        } else {
            prefs.gamingPackages + packageName
        }
        prefs.copy(gamingPackages = updated)
    }

    suspend fun recordAppLaunch(packageName: String) = updatePreferences { prefs ->
        val updated = (listOf(packageName) + prefs.localRecentPackages.filterNot { it == packageName })
            .take(12)
        prefs.copy(localRecentPackages = updated)
    }
}
