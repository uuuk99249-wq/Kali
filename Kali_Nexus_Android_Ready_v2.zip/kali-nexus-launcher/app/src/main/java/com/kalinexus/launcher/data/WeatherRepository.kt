package com.kalinexus.launcher.data

import com.kalinexus.launcher.model.WeatherState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class WeatherRepository {

    suspend fun fetchLiveWeather(
        latitude: Double,
        longitude: Double,
        locationLabel: String
    ): Result<WeatherState> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint =
                "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current=temperature_2m,weather_code,wind_speed_10m&timezone=auto"
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 8_000
                requestMethod = "GET"
            }

            try {
                val responseCode = connection.responseCode
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    error("Weather service returned HTTP $responseCode")
                }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(body)
                val current = root.getJSONObject("current")
                val temp = current.getDouble("temperature_2m")
                val wind = current.getDouble("wind_speed_10m")
                val code = current.getInt("weather_code")

                WeatherState(
                    temperatureCelsius = temp,
                    conditionLabel = mapWmoWeatherCode(code),
                    windKmh = wind,
                    locationLabel = locationLabel,
                    isLiveData = true,
                    isLoading = false,
                    lastUpdatedEpochMs = System.currentTimeMillis(),
                    errorMessage = null
                )
            } finally {
                connection.disconnect()
            }
        }
    }

    private fun mapWmoWeatherCode(code: Int): String = when (code) {
        0 -> "Clear Sky"
        1, 2 -> "Partly Cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        51, 53, 55 -> "Drizzle"
        61, 63, 65 -> "Rain"
        66, 67 -> "Freezing Rain"
        71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Rain Showers"
        85, 86 -> "Snow Showers"
        95, 96, 99 -> "Thunderstorm"
        else -> "Atmospheric"
    }
}
