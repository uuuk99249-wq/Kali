package com.kalinexus.launcher.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import com.kalinexus.launcher.model.DeviceTelemetry
import java.io.File
import kotlin.math.roundToInt

class DeviceTelemetryProvider(private val context: Context) {

    fun readSnapshot(): DeviceTelemetry {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memoryInfo)

        val statFs = runCatching { StatFs(Environment.getDataDirectory().path) }.getOrNull()
        val availStorage = statFs?.availableBytes ?: 0L
        val totalStorage = statFs?.totalBytes ?: 0L

        val batteryIntent = runCatching {
            context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }.getOrNull()

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPercent = if (level >= 0 && scale > 0) {
            ((level * 100f) / scale).roundToInt().coerceIn(0, 100)
        } else {
            0
        }

        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val batterySource = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Adapter"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> if (isCharging) "Charging" else "Discharging"
        }

        val healthInt = batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val batteryHealth = when (healthInt) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Nominal"
        }

        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val batteryTempCelsius = if (tempTenths != null && tempTenths != Int.MIN_VALUE && tempTenths > 0) {
            tempTenths / 10f
        } else {
            null
        }

        val connectivity =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = connectivity?.activeNetwork
        val caps = activeNetwork?.let { connectivity.getNetworkCapabilities(it) }
        val networkConnected = caps != null &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val isVpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        val isMetered = caps != null &&
            !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)

        val networkType = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> "Bluetooth PAN"
            isVpn -> "VPN"
            else -> "Connected"
        }

        val cpuCores = Runtime.getRuntime().availableProcessors()
        val cpuInfoLabel = readProcCpuModel()
        val cpuFreqs = readCpuFrequenciesMhz(cpuCores)
        val thermalLabel = readThermalStatus()

        return DeviceTelemetry(
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            brand = Build.BRAND.replaceFirstChar { it.uppercase() },
            deviceCodename = Build.DEVICE,
            hardwareBoard = Build.HARDWARE,
            androidVersion = Build.VERSION.RELEASE ?: "Unknown",
            apiLevel = Build.VERSION.SDK_INT,
            securityPatch = Build.VERSION.SECURITY_PATCH ?: "Unavailable",
            buildId = Build.ID,
            availRamBytes = memoryInfo.availMem,
            totalRamBytes = memoryInfo.totalMem,
            availStorageBytes = availStorage,
            totalStorageBytes = totalStorage,
            batteryPercent = batteryPercent,
            isCharging = isCharging,
            batterySource = batterySource,
            batteryHealth = batteryHealth,
            batteryTempCelsius = batteryTempCelsius,
            networkConnected = networkConnected,
            networkType = networkType,
            isVpnActive = isVpn,
            isMetered = isMetered,
            cpuCores = cpuCores,
            supportedAbis = Build.SUPPORTED_ABIS.toList(),
            cpuInfoLabel = cpuInfoLabel,
            cpuCurrentFreqsMhz = cpuFreqs,
            thermalStatusLabel = thermalLabel
        )
    }

    private fun readProcCpuModel(): String? {
        return runCatching {
            val file = File("/proc/cpuinfo")
            if (!file.canRead()) return@runCatching null
            val lines = file.readLines()
            val hardwareLine = lines.firstOrNull {
                it.startsWith("Hardware", ignoreCase = true) ||
                    it.startsWith("model name", ignoreCase = true)
            }
            hardwareLine?.substringAfter(":")?.trim()?.takeIf { it.isNotEmpty() }
        }.getOrNull()
    }

    private fun readCpuFrequenciesMhz(cores: Int): List<Int> {
        val result = mutableListOf<Int>()
        val limit = cores.coerceIn(1, 16)
        for (i in 0 until limit) {
            val mhz = runCatching {
                val file = File("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")
                if (!file.canRead()) return@runCatching null
                val khz = file.readText().trim().toIntOrNull() ?: return@runCatching null
                khz / 1000
            }.getOrNull()
            if (mhz != null && mhz > 0) {
                result.add(mhz)
            }
        }
        return result
    }

    private fun readThermalStatus(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "Unavailable"
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            ?: return "Unavailable"
        return when (powerManager.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Nominal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light Warmth"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate Load"
            PowerManager.THERMAL_STATUS_SEVERE -> "High Thermal"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Thermal Shutdown"
            else -> "Nominal"
        }
    }

    companion object {
        fun formatBytesToGb(bytes: Long): String {
            if (bytes <= 0L) return "0.0 GB"
            val gb = bytes / (1024.0 * 1024.0 * 1024.0)
            return String.format("%.1f GB", gb)
        }

        fun formatBytesToMbOrGb(bytes: Long): String {
            if (bytes <= 0L) return "0 MB"
            val gb = bytes / (1024.0 * 1024.0 * 1024.0)
            return if (gb >= 1.0) {
                String.format("%.2f GB", gb)
            } else {
                val mb = bytes / (1024.0 * 1024.0)
                String.format("%.0f MB", mb)
            }
        }
    }
}
