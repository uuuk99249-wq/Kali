package com.kalinexus.launcher.system

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.provider.Settings
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.kalinexus.launcher.model.AppSortOrder
import com.kalinexus.launcher.model.IconPackInfo
import com.kalinexus.launcher.model.InstalledApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser

class AppDiscoveryManager(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager
    private val launcherApps: LauncherApps? =
        context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps

    private val iconCache = object : LruCache<String, ImageBitmap>(180) {}

    fun observePackageChanges(): Flow<Unit> = callbackFlow {
        val service = launcherApps
        if (service == null) {
            trySend(Unit)
            close()
            return@callbackFlow
        }

        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
                packageName?.let { clearIconsForPackage(it) }
                trySend(Unit)
            }

            override fun onPackageAdded(packageName: String?, user: UserHandle?) {
                trySend(Unit)
            }

            override fun onPackageChanged(packageName: String?, user: UserHandle?) {
                packageName?.let { clearIconsForPackage(it) }
                trySend(Unit)
            }

            override fun onPackagesAvailable(
                packageNames: Array<out String>?,
                user: UserHandle?,
                replacing: Boolean
            ) {
                trySend(Unit)
            }

            override fun onPackagesUnavailable(
                packageNames: Array<out String>?,
                user: UserHandle?,
                replacing: Boolean
            ) {
                trySend(Unit)
            }
        }

        service.registerCallback(callback)
        trySend(Unit)
        awaitClose {
            runCatching { service.unregisterCallback(callback) }
        }
    }

    private fun clearIconsForPackage(packageName: String) {
        val keysToRemove = iconCache.snapshot().keys.filter { it.startsWith("$packageName|") }
        keysToRemove.forEach { iconCache.remove(it) }
    }

    suspend fun loadLaunchableApps(iconPackPackage: String? = null): List<InstalledApp> =
        withContext(Dispatchers.IO) {
            val ownPackage = context.packageName
            val iconPackMap = if (!iconPackPackage.isNullOrBlank()) {
                loadIconPackMapping(iconPackPackage)
            } else {
                emptyMap()
            }
            val iconPackRes = if (!iconPackPackage.isNullOrBlank()) {
                runCatching { packageManager.getResourcesForApplication(iconPackPackage) }.getOrNull()
            } else {
                null
            }

            val launcherService = launcherApps
            val rawList: List<InstalledApp> = if (launcherService != null) {
                val activities = launcherService.getActivityList(null, Process.myUserHandle())
                activities.mapNotNull { info ->
                    val pkg = info.applicationInfo.packageName
                    if (pkg == ownPackage) return@mapNotNull null
                    val component = info.componentName
                    val cacheKey = "$pkg|${component.className}|${iconPackPackage ?: "sys"}"
                    val cachedIcon = iconCache.get(cacheKey) ?: run {
                        val packedDrawable = resolvePackIconDrawable(
                            component = component,
                            iconPackPackage = iconPackPackage,
                            iconPackRes = iconPackRes,
                            iconPackMap = iconPackMap
                        )
                        val drawable = packedDrawable ?: info.getBadgedIcon(0)
                        drawableToImageBitmap(drawable)?.also { iconCache.put(cacheKey, it) }
                    }

                    val pkgInfo = runCatching {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                        } else {
                            @Suppress("DEPRECATION")
                            packageManager.getPackageInfo(pkg, 0)
                        }
                    }.getOrNull()

                    val isSystem = (info.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val isGame = info.applicationInfo.category == ApplicationInfo.CATEGORY_GAME

                    InstalledApp(
                        packageName = pkg,
                        activityName = component.className,
                        label = info.label?.toString()?.takeIf { it.isNotBlank() } ?: pkg,
                        isSystemApp = isSystem,
                        isGameCategory = isGame,
                        firstInstallTime = pkgInfo?.firstInstallTime ?: 0L,
                        lastUpdateTime = pkgInfo?.lastUpdateTime ?: 0L,
                        icon = cachedIcon
                    )
                }
            } else {
                val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    packageManager.queryIntentActivities(
                        mainIntent,
                        PackageManager.ResolveInfoFlags.of(0)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    packageManager.queryIntentActivities(mainIntent, 0)
                }
                resolveInfos.mapNotNull { ri ->
                    val pkg = ri.activityInfo.packageName
                    if (pkg == ownPackage) return@mapNotNull null
                    val cls = ri.activityInfo.name
                    val cacheKey = "$pkg|$cls|sys"
                    val icon = iconCache.get(cacheKey) ?: drawableToImageBitmap(
                        ri.loadIcon(packageManager)
                    )?.also { iconCache.put(cacheKey, it) }
                    val appInfo = ri.activityInfo.applicationInfo
                    InstalledApp(
                        packageName = pkg,
                        activityName = cls,
                        label = ri.loadLabel(packageManager)?.toString() ?: pkg,
                        isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                        isGameCategory = appInfo.category == ApplicationInfo.CATEGORY_GAME,
                        firstInstallTime = 0L,
                        lastUpdateTime = 0L,
                        icon = icon
                    )
                }
            }

            rawList
                .distinctBy { "${it.packageName}/${it.activityName}" }
                .sortedBy { it.label.lowercase() }
        }

    fun discoverInstalledIconPacks(): List<IconPackInfo> {
        val actions = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME")
        val discovered = linkedMapOf<String, IconPackInfo>()

        for (action in actions) {
            val intent = Intent(action)
            val matches = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.queryIntentActivities(
                    intent,
                    PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            }
            for (ri in matches) {
                val pkg = ri.activityInfo.packageName
                if (pkg !in discovered) {
                    discovered[pkg] = IconPackInfo(
                        packageName = pkg,
                        label = ri.loadLabel(packageManager)?.toString() ?: pkg
                    )
                }
            }
        }
        return discovered.values.sortedBy { it.label.lowercase() }
    }

    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
            ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    suspend fun getRecentlyUsedPackages(limit: Int = 8): List<String> =
        withContext(Dispatchers.IO) {
            if (!hasUsageStatsPermission()) return@withContext emptyList()
            val usageStatsManager =
                context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                    ?: return@withContext emptyList()
            val end = System.currentTimeMillis()
            val start = end - 1000L * 60L * 60L * 24L * 3L // last 72h
            val stats = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                start,
                end
            ) ?: return@withContext emptyList()

            stats
                .filter { it.packageName != context.packageName && it.lastTimeUsed > 0L }
                .sortedByDescending { it.lastTimeUsed }
                .map { it.packageName }
                .distinct()
                .take(limit)
        }

    fun launchApp(app: InstalledApp): Result<Unit> {
        return runCatching {
            val component = ComponentName(app.packageName, app.activityName)
            val service = launcherApps
            if (service != null) {
                service.startMainActivity(component, Process.myUserHandle(), null, null)
            } else {
                val intent = packageManager.getLaunchIntentForPackage(app.packageName)
                    ?: Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                        setComponent(component)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        }
    }

    fun openAppInfo(packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    fun requestUninstallApp(packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    private fun resolvePackIconDrawable(
        component: ComponentName,
        iconPackPackage: String?,
        iconPackRes: Resources?,
        iconPackMap: Map<String, String>
    ): Drawable? {
        if (iconPackPackage.isNullOrBlank() || iconPackRes == null || iconPackMap.isEmpty()) {
            return null
        }
        val key = "ComponentInfo{${component.packageName}/${component.className}}"
        val drawableName = iconPackMap[key] ?: return null
        val resId = iconPackRes.getIdentifier(drawableName, "drawable", iconPackPackage)
        if (resId == 0) return null
        return runCatching { iconPackRes.getDrawable(resId, null) }.getOrNull()
    }

    private fun loadIconPackMapping(iconPackPackage: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        runCatching {
            val res = packageManager.getResourcesForApplication(iconPackPackage)
            val xmlResId = res.getIdentifier("appfilter", "xml", iconPackPackage)
            if (xmlResId != 0) {
                val parser = res.getXml(xmlResId)
                var eventType = parser.eventType
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG && parser.name == "item") {
                        val component = parser.getAttributeValue(null, "component")
                        val drawable = parser.getAttributeValue(null, "drawable")
                        if (!component.isNullOrBlank() && !drawable.isNullOrBlank()) {
                            map[component] = drawable
                        }
                    }
                    eventType = parser.next()
                }
            }
        }
        return map
    }

    private fun drawableToImageBitmap(drawable: Drawable): ImageBitmap? {
        return runCatching {
            val targetSize = 144
            if (drawable is BitmapDrawable && drawable.bitmap != null) {
                val bmp = drawable.bitmap
                if (bmp.width <= targetSize && bmp.height <= targetSize) {
                    return bmp.asImageBitmap()
                }
            }
            val width = drawable.intrinsicWidth.takeIf { it > 0 }?.coerceAtMost(targetSize) ?: targetSize
            val height = drawable.intrinsicHeight.takeIf { it > 0 }?.coerceAtMost(targetSize) ?: targetSize
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            bitmap.asImageBitmap()
        }.getOrNull()
    }

    companion object {
        fun filterAndSortApps(
            apps: List<InstalledApp>,
            hiddenPackages: Set<String>,
            query: String,
            searchPackageNames: Boolean,
            sortOrder: AppSortOrder
        ): List<InstalledApp> {
            val normalizedQuery = query.trim().lowercase()
            val visible = apps.filter { app ->
                if (app.packageName in hiddenPackages) return@filter false
                if (normalizedQuery.isEmpty()) return@filter true
                app.label.lowercase().contains(normalizedQuery) ||
                    (searchPackageNames && app.packageName.lowercase().contains(normalizedQuery))
            }
            return when (sortOrder) {
                AppSortOrder.ALPHA_ASC -> visible.sortedBy { it.label.lowercase() }
                AppSortOrder.ALPHA_DESC -> visible.sortedByDescending { it.label.lowercase() }
            }
        }
    }
}
