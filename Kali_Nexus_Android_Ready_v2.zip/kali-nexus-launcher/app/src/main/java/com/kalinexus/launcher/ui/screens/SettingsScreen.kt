package com.kalinexus.launcher.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.kalinexus.launcher.BuildConfig
import com.kalinexus.launcher.model.AnimationSpeed
import com.kalinexus.launcher.model.AppIconStyle
import com.kalinexus.launcher.model.AppSortOrder
import com.kalinexus.launcher.model.ClockSizePreset
import com.kalinexus.launcher.model.CyberThemePreset
import com.kalinexus.launcher.model.IconSizePreset
import com.kalinexus.launcher.model.WallpaperPreset
import com.kalinexus.launcher.ui.components.CyberSurfaceCard
import com.kalinexus.launcher.ui.components.SectionHeader
import com.kalinexus.launcher.ui.theme.LocalKaliPalette
import com.kalinexus.launcher.viewmodel.LauncherUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    state: LauncherUiState,
    onSetDefaultHome: () -> Unit,
    onSelectTheme: (CyberThemePreset) -> Unit,
    onSelectWallpaper: (WallpaperPreset, String?) -> Unit,
    onSetWallpaperDim: (Float) -> Unit,
    onSetIconSize: (IconSizePreset) -> Unit,
    onSetIconStyle: (AppIconStyle) -> Unit,
    onSetIconPack: (String?) -> Unit,
    onSetAnimationSpeed: (AnimationSpeed) -> Unit,
    onSetGrid: (Int, Int) -> Unit,
    onSetHomePages: (Int) -> Unit,
    onSetDock: (Boolean, Int, Boolean) -> Unit,
    onSetClock: (Boolean, Boolean, ClockSizePreset) -> Unit,
    onSetWeather: (Boolean, Boolean, String, Double, Double) -> Unit,
    onSetSearchSettings: (Boolean, Boolean, Boolean, AppSortOrder) -> Unit,
    onUnhideApp: (String) -> Unit,
    onExportBackupJson: () -> String,
    onImportBackupJson: (String) -> Unit,
    onNotify: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current
    val context = LocalContext.current
    val prefs = state.preferences

    var cityInput by remember(prefs.weatherCityLabel) { mutableStateOf(prefs.weatherCityLabel) }
    var latInput by remember(prefs.weatherLatitude) { mutableStateOf(prefs.weatherLatitude.toString()) }
    var lonInput by remember(prefs.weatherLongitude) { mutableStateOf(prefs.weatherLongitude.toString()) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            onSelectWallpaper(WallpaperPreset.CUSTOM_IMAGE, uri.toString())
            onNotify("Custom wallpaper applied")
        }
    }

    val backupExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val payload = onExportBackupJson()
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(payload.toByteArray(Charsets.UTF_8))
                }
            }.onSuccess {
                onNotify("Backup saved successfully")
            }.onFailure {
                onNotify("Failed to export backup")
            }
        }
    }

    val backupImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader().readText()
                } ?: ""
            }.onSuccess { content ->
                onImportBackupJson(content)
            }.onFailure {
                onNotify("Unable to read selected backup file")
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Launcher Settings",
                subtitle = "PERSISTENT LOCAL DATASTORE CONFIGURATION"
            )
        }

        // Default Home Binding
        item {
            CyberSurfaceCard(highlightBorder = !state.securityOverview.isDefaultHomeLauncher) {
                Text("DEFAULT HOME LAUNCHER", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (state.securityOverview.isDefaultHomeLauncher) {
                        "KALI NEXUS is currently active as your device's default Home application."
                    } else {
                        "Assign KALI NEXUS as the default Home app so the system Home gesture returns here."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onSetDefaultHome,
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primaryAccent)
                ) {
                    Text(
                        if (state.securityOverview.isDefaultHomeLauncher) "Manage Default Home" else "Set as Default Launcher",
                        color = palette.voidBlack
                    )
                }
            }
        }

        // Theme Selection
        item {
            CyberSurfaceCard {
                Text("CYBER THEME PALETTE", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CyberThemePreset.entries.forEach { preset ->
                        SelectableChip(
                            label = preset.displayName,
                            selected = prefs.themePreset == preset,
                            onClick = { onSelectTheme(preset) }
                        )
                    }
                }
            }
        }

        // Wallpaper Selection
        item {
            CyberSurfaceCard {
                Text("WALLPAPER & SURFACE DIMMING", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WallpaperPreset.entries.filter { it != WallpaperPreset.CUSTOM_IMAGE }.forEach { wp ->
                        SelectableChip(
                            label = wp.displayName,
                            selected = prefs.wallpaperPreset == wp,
                            onClick = { onSelectWallpaper(wp, null) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        photoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    border = BorderStroke(1.dp, palette.primaryAccent.copy(alpha = 0.6f))
                ) {
                    Text("Pick Custom Gallery Wallpaper", color = palette.primaryAccent)
                }
                if (prefs.wallpaperPreset == WallpaperPreset.CUSTOM_IMAGE) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Wallpaper Dim Scrim: ${(prefs.wallpaperDimAlpha * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textSecondary
                    )
                    Slider(
                        value = prefs.wallpaperDimAlpha,
                        onValueChange = onSetWallpaperDim,
                        valueRange = 0.1f..0.85f,
                        colors = SliderDefaults.colors(
                            thumbColor = palette.primaryAccent,
                            activeTrackColor = palette.primaryAccent
                        )
                    )
                }
            }
        }

        // Icon Size, Style, and Third-Party Icon Packs
        item {
            CyberSurfaceCard {
                Text("ICONS & ICON PACKS", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Icon Size", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconSizePreset.entries.forEach { size ->
                        SelectableChip(
                            label = "${size.displayName} (${size.dpValue}dp)",
                            selected = prefs.iconSize == size,
                            onClick = { onSetIconSize(size) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("Icon Presentation", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppIconStyle.entries.forEach { style ->
                        SelectableChip(
                            label = style.displayName,
                            selected = prefs.iconStyle == style,
                            onClick = { onSetIconStyle(style) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("Installed Icon Packs", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SelectableChip(
                        label = "System Default",
                        selected = prefs.selectedIconPackPackage == null,
                        onClick = { onSetIconPack(null) }
                    )
                    state.availableIconPacks.forEach { pack ->
                        SelectableChip(
                            label = pack.label,
                            selected = prefs.selectedIconPackPackage == pack.packageName,
                            onClick = { onSetIconPack(pack.packageName) }
                        )
                    }
                }
                if (state.availableIconPacks.isEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "No external ADW/Nova icon packs detected on device.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textMuted
                    )
                }
            }
        }

        // Home Grid, Pages & Dock
        item {
            CyberSurfaceCard {
                Text("GRID, PAGES & DOCK", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Grid Columns", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(4, 5).forEach { cols ->
                        SelectableChip(
                            label = "$cols Columns",
                            selected = prefs.gridColumns == cols,
                            onClick = { onSetGrid(cols, prefs.gridRows) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("Home Pages", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (1..4).forEach { pages ->
                        SelectableChip(
                            label = "$pages",
                            selected = prefs.homePageCount == pages,
                            onClick = { onSetHomePages(pages) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                SettingSwitchRow(
                    title = "Show Bottom Dock",
                    checked = prefs.showDock,
                    onCheckedChange = { onSetDock(it, prefs.dockCount, prefs.showDockLabels) }
                )
                SettingSwitchRow(
                    title = "Show Dock App Labels",
                    checked = prefs.showDockLabels,
                    onCheckedChange = { onSetDock(prefs.showDock, prefs.dockCount, it) }
                )
                Text("Dock Slot Capacity", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(4, 5, 6).forEach { cnt ->
                        SelectableChip(
                            label = "$cnt Slots",
                            selected = prefs.dockCount == cnt,
                            onClick = { onSetDock(prefs.showDock, cnt, prefs.showDockLabels) }
                        )
                    }
                }
            }
        }

        // Clock, Weather & Animations
        item {
            CyberSurfaceCard {
                Text("CLOCK, WEATHER & ANIMATIONS", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                Spacer(modifier = Modifier.height(8.dp))
                SettingSwitchRow(
                    title = "24-Hour Digital Clock",
                    checked = prefs.use24HourClock,
                    onCheckedChange = { onSetClock(it, prefs.showClockSeconds, prefs.clockSize) }
                )
                SettingSwitchRow(
                    title = "Show Seconds",
                    checked = prefs.showClockSeconds,
                    onCheckedChange = { onSetClock(prefs.use24HourClock, it, prefs.clockSize) }
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ClockSizePreset.entries.forEach { sz ->
                        SelectableChip(
                            label = sz.displayName,
                            selected = prefs.clockSize == sz,
                            onClick = { onSetClock(prefs.use24HourClock, prefs.showClockSeconds, sz) }
                        )
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = palette.hairlineBorder)
                Text("Motion Speed", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AnimationSpeed.entries.forEach { spd ->
                        SelectableChip(
                            label = spd.displayName,
                            selected = prefs.animationSpeed == spd,
                            onClick = { onSetAnimationSpeed(spd) }
                        )
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = palette.hairlineBorder)
                SettingSwitchRow(
                    title = "Show Weather Widget",
                    checked = prefs.showWeatherWidget,
                    onCheckedChange = {
                        onSetWeather(
                            it,
                            prefs.useLiveWeather,
                            cityInput,
                            latInput.toDoubleOrNull() ?: prefs.weatherLatitude,
                            lonInput.toDoubleOrNull() ?: prefs.weatherLongitude
                        )
                    }
                )
                SettingSwitchRow(
                    title = "Live Open-Meteo Sync",
                    checked = prefs.useLiveWeather,
                    onCheckedChange = {
                        onSetWeather(
                            prefs.showWeatherWidget,
                            it,
                            cityInput,
                            latInput.toDoubleOrNull() ?: prefs.weatherLatitude,
                            lonInput.toDoubleOrNull() ?: prefs.weatherLongitude
                        )
                    }
                )
                val fieldColors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.primaryAccent,
                    unfocusedBorderColor = palette.hairlineBorder,
                    focusedContainerColor = palette.graphiteDeep,
                    unfocusedContainerColor = palette.graphiteDeep,
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary,
                    focusedLabelColor = palette.primaryAccent,
                    unfocusedLabelColor = palette.textMuted
                )
                OutlinedTextField(
                    value = cityInput,
                    onValueChange = { cityInput = it },
                    label = { Text("Weather Location Label") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = latInput,
                        onValueChange = { latInput = it },
                        label = { Text("Latitude") },
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = lonInput,
                        onValueChange = { lonInput = it },
                        label = { Text("Longitude") },
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                TextButton(
                    onClick = {
                        onSetWeather(
                            prefs.showWeatherWidget,
                            prefs.useLiveWeather,
                            cityInput.ifBlank { "Local Sector" },
                            latInput.toDoubleOrNull() ?: prefs.weatherLatitude,
                            lonInput.toDoubleOrNull() ?: prefs.weatherLongitude
                        )
                        onNotify("Weather coordinates saved")
                    }
                ) {
                    Text("Apply Weather Location", color = palette.primaryAccent)
                }
            }
        }

        // Search & Drawer Preferences
        item {
            CyberSurfaceCard {
                Text("APP DRAWER & SEARCH", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                Spacer(modifier = Modifier.height(8.dp))
                SettingSwitchRow(
                    title = "Show Recently Used Apps",
                    checked = prefs.showRecentApps,
                    onCheckedChange = {
                        onSetSearchSettings(
                            it,
                            prefs.autoFocusDrawerSearch,
                            prefs.searchPackageNames,
                            prefs.sortOrder
                        )
                    }
                )
                SettingSwitchRow(
                    title = "Auto-Focus Search on Open",
                    checked = prefs.autoFocusDrawerSearch,
                    onCheckedChange = {
                        onSetSearchSettings(
                            prefs.showRecentApps,
                            it,
                            prefs.searchPackageNames,
                            prefs.sortOrder
                        )
                    }
                )
                SettingSwitchRow(
                    title = "Match Package Names in Search",
                    checked = prefs.searchPackageNames,
                    onCheckedChange = {
                        onSetSearchSettings(
                            prefs.showRecentApps,
                            prefs.autoFocusDrawerSearch,
                            it,
                            prefs.sortOrder
                        )
                    }
                )
            }
        }

        // Hidden Apps
        if (state.hiddenApps.isNotEmpty()) {
            item {
                CyberSurfaceCard {
                    Text("HIDDEN APPS (${state.hiddenApps.size})", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                    Spacer(modifier = Modifier.height(8.dp))
                    state.hiddenApps.forEach { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(app.label, color = palette.textPrimary)
                            TextButton(onClick = { onUnhideApp(app.packageName) }) {
                                Text("Restore", color = palette.primaryAccent)
                            }
                        }
                    }
                }
            }
        }

        // Backup & Restore
        item {
            CyberSurfaceCard {
                Text("BACKUP & RESTORE PREFERENCES", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Export or restore your layout, dock, favorites, hidden apps, and theme configuration as portable JSON.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { backupExportLauncher.launch("kali-nexus-backup.json") },
                        border = BorderStroke(1.dp, palette.primaryAccent)
                    ) {
                        Text("Export JSON", color = palette.primaryAccent)
                    }
                    OutlinedButton(
                        onClick = { backupImportLauncher.launch(arrayOf("application/json", "*/*")) },
                        border = BorderStroke(1.dp, palette.hairlineBorder)
                    ) {
                        Text("Restore JSON", color = palette.textPrimary)
                    }
                }
            }
        }

        // About KALI NEXUS
        item {
            CyberSurfaceCard {
                Text("ABOUT KALI NEXUS", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "KALI NEXUS — Cyber Edition Launcher (${BuildConfig.VERSION_NAME})",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Native Kotlin & Jetpack Compose Home Launcher for Android 10+ (API 29–35). Zero root required. Uses official LauncherApps, DataStore Preferences, ActivityManager, StatFs, BatteryManager, ConnectivityManager, and RoleManager APIs.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary
                )
            }
        }
    }
}

@Composable
private fun SelectableChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalKaliPalette.current
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (selected) palette.primaryAccent.copy(alpha = 0.16f) else palette.graphiteDeep,
        border = BorderStroke(1.dp, if (selected) palette.primaryAccent else palette.hairlineBorder),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) palette.primaryAccent else palette.textSecondary,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalKaliPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            color = palette.textPrimary,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.voidBlack,
                checkedTrackColor = palette.primaryAccent
            )
        )
    }
}
