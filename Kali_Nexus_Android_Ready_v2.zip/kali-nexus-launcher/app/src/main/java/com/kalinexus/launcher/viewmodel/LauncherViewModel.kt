package com.kalinexus.launcher.viewmodel

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kalinexus.launcher.KaliNexusApplication
import com.kalinexus.launcher.data.BackupManager
import com.kalinexus.launcher.model.AnimationSpeed
import com.kalinexus.launcher.model.AppIconStyle
import com.kalinexus.launcher.model.AppSortOrder
import com.kalinexus.launcher.model.ClockSizePreset
import com.kalinexus.launcher.model.CyberThemePreset
import com.kalinexus.launcher.model.DeviceTelemetry
import com.kalinexus.launcher.model.IconPackInfo
import com.kalinexus.launcher.model.IconSizePreset
import com.kalinexus.launcher.model.InstalledApp
import com.kalinexus.launcher.model.LauncherPreferences
import com.kalinexus.launcher.model.MainSection
import com.kalinexus.launcher.model.SecurityOverview
import com.kalinexus.launcher.model.WallpaperPreset
import com.kalinexus.launcher.model.WeatherState
import com.kalinexus.launcher.system.AppDiscoveryManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LauncherUiState(
    val currentSection: MainSection = MainSection.HOME,
    val isAppDrawerOpen: Boolean = false,
    val currentHomePage: Int = 0,
    val drawerSearchQuery: String = "",
    val preferences: LauncherPreferences = LauncherPreferences(),
    val allApps: List<InstalledApp> = emptyList(),
    val filteredDrawerApps: List<InstalledApp> = emptyList(),
    val favoriteApps: List<InstalledApp> = emptyList(),
    val recentApps: List<InstalledApp> = emptyList(),
    val dockApps: List<InstalledApp> = emptyList(),
    val hiddenApps: List<InstalledApp> = emptyList(),
    val gamingApps: List<InstalledApp> = emptyList(),
    val availableIconPacks: List<IconPackInfo> = emptyList(),
    val telemetry: DeviceTelemetry = DeviceTelemetry(),
    val weather: WeatherState = WeatherState(),
    val securityOverview: SecurityOverview = SecurityOverview(),
    val statusBannerMessage: String? = null
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as KaliNexusApplication
    private val settingsRepo = app.settingsRepository
    private val appDiscovery = app.appDiscoveryManager
    private val telemetryProvider = app.telemetryProvider
    private val securityProvider = app.securityAuditProvider
    private val weatherRepo = app.weatherRepository

    private val _currentSection = MutableStateFlow(MainSection.HOME)
    private val _isAppDrawerOpen = MutableStateFlow(false)
    private val _currentHomePage = MutableStateFlow(0)
    private val _drawerSearchQuery = MutableStateFlow("")
    private val _allApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    private val _usageRecentPackages = MutableStateFlow<List<String>>(emptyList())
    private val _telemetry = MutableStateFlow(telemetryProvider.readSnapshot())
    private val _weather = MutableStateFlow(WeatherState())
    private val _iconPacks = MutableStateFlow<List<IconPackInfo>>(emptyList())
    private val _statusMessage = MutableStateFlow<String?>(null)

    val preferencesFlow: StateFlow<LauncherPreferences> = settingsRepo.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, LauncherPreferences())

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshTelemetry()
        }
    }

    val uiState: StateFlow<LauncherUiState> = combine(
        combine(_currentSection, _isAppDrawerOpen, _currentHomePage, _drawerSearchQuery) { section, drawer, page, query ->
            Quad(section, drawer, page, query)
        },
        preferencesFlow,
        _allApps,
        _usageRecentPackages,
        combine(_telemetry, _weather, _iconPacks, _statusMessage) { tel, w, packs, msg ->
            Quad(tel, w, packs, msg)
        }
    ) { navQuad, prefs, apps, usageRecents, sysQuad ->
        val (section, drawerOpen, homePage, searchQuery) = navQuad
        val (telemetry, weather, iconPacks, statusMsg) = sysQuad

        val byPkg = apps.associateBy { it.packageName }
        val filteredDrawer = AppDiscoveryManager.filterAndSortApps(
            apps = apps,
            hiddenPackages = prefs.hiddenPackages,
            query = searchQuery,
            searchPackageNames = prefs.searchPackageNames,
            sortOrder = prefs.sortOrder
        )

        val favorites = prefs.favoritePackages
            .mapNotNull { byPkg[it] }
            .filterNot { it.packageName in prefs.hiddenPackages }
            .sortedBy { it.label.lowercase() }

        val mergedRecentPkgs = (usageRecents + prefs.localRecentPackages).distinct()
        val recents = mergedRecentPkgs
            .mapNotNull { byPkg[it] }
            .filterNot { it.packageName in prefs.hiddenPackages }
            .take(6)

        val dock = prefs.dockPackages
            .mapNotNull { byPkg[it] }
            .filterNot { it.packageName in prefs.hiddenPackages }
            .take(prefs.dockCount)

        val hidden = prefs.hiddenPackages
            .mapNotNull { byPkg[it] }
            .sortedBy { it.label.lowercase() }

        val games = apps
            .filter { it.isGameCategory || it.packageName in prefs.gamingPackages }
            .filterNot { it.packageName in prefs.hiddenPackages }
            .sortedBy { it.label.lowercase() }

        val hasUsageAccess = appDiscovery.hasUsageStatsPermission()
        val security = securityProvider.buildOverview(
            apps = apps,
            telemetry = telemetry,
            hasUsageAccess = hasUsageAccess
        )

        LauncherUiState(
            currentSection = section,
            isAppDrawerOpen = drawerOpen,
            currentHomePage = homePage.coerceIn(0, (prefs.homePageCount - 1).coerceAtLeast(0)),
            drawerSearchQuery = searchQuery,
            preferences = prefs,
            allApps = apps,
            filteredDrawerApps = filteredDrawer,
            favoriteApps = favorites,
            recentApps = recents,
            dockApps = dock,
            hiddenApps = hidden,
            gamingApps = games,
            availableIconPacks = iconPacks,
            telemetry = telemetry,
            weather = weather.copy(locationLabel = prefs.weatherCityLabel),
            securityOverview = security,
            statusBannerMessage = statusMsg
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, LauncherUiState())

    init {
        registerBatteryObserver()
        observePackagesAndIconPacks()
        refreshTelemetry()
        refreshRecentApps()
    }

    private fun registerBatteryObserver() {
        runCatching {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            ContextCompat.registerReceiver(
                getApplication(),
                batteryReceiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        }
    }

    private fun observePackagesAndIconPacks() {
        viewModelScope.launch {
            combine(
                appDiscovery.observePackageChanges(),
                preferencesFlow.map { it.selectedIconPackPackage }.distinctUntilChanged()
            ) { _, iconPack -> iconPack }
                .collect { iconPack ->
                    val loaded = appDiscovery.loadLaunchableApps(iconPack)
                    _allApps.value = loaded
                    _iconPacks.value = appDiscovery.discoverInstalledIconPacks()
                    seedSmartDockDefaults(loaded)
                }
        }
    }

    private suspend fun seedSmartDockDefaults(apps: List<InstalledApp>) {
        if (apps.isEmpty()) return
        val preferredKeywords = listOf("dialer", "phone", "messaging", "mms", "browser", "chrome", "camera", "settings")
        val seeded = mutableListOf<String>()
        for (keyword in preferredKeywords) {
            val match = apps.firstOrNull {
                it.packageName.contains(keyword, ignoreCase = true) ||
                    it.label.contains(keyword, ignoreCase = true)
            }
            if (match != null && match.packageName !in seeded) {
                seeded.add(match.packageName)
            }
            if (seeded.size >= 5) break
        }
        if (seeded.size < 4) {
            apps.take(5 - seeded.size).forEach {
                if (it.packageName !in seeded) seeded.add(it.packageName)
            }
        }
        settingsRepo.seedInitialDockIfEmpty(seeded)
    }

    fun selectSection(section: MainSection) {
        _currentSection.value = section
        if (section != MainSection.HOME) {
            _isAppDrawerOpen.value = false
        }
        refreshTelemetry()
    }

    fun openAppDrawer() {
        _isAppDrawerOpen.value = true
        refreshRecentApps()
    }

    fun closeAppDrawer() {
        _isAppDrawerOpen.value = false
        _drawerSearchQuery.value = ""
    }

    fun setHomePage(page: Int) {
        _currentHomePage.value = page
    }

    fun onHomeButtonPressed() {
        _isAppDrawerOpen.value = false
        _drawerSearchQuery.value = ""
        _currentSection.value = MainSection.HOME
        _currentHomePage.value = 0
        refreshTelemetry()
    }

    fun updateSearchQuery(query: String) {
        _drawerSearchQuery.value = query
    }

    fun refreshTelemetry() {
        _telemetry.value = telemetryProvider.readSnapshot()
    }

    fun refreshRecentApps() {
        viewModelScope.launch {
            _usageRecentPackages.value = appDiscovery.getRecentlyUsedPackages()
        }
    }

    fun refreshWeather() {
        val prefs = preferencesFlow.value
        if (!prefs.useLiveWeather) {
            _weather.value = WeatherState(
                temperatureCelsius = null,
                conditionLabel = "Offline Stand-by",
                locationLabel = prefs.weatherCityLabel,
                isLiveData = false
            )
            return
        }
        viewModelScope.launch {
            _weather.value = _weather.value.copy(isLoading = true, errorMessage = null)
            weatherRepo.fetchLiveWeather(
                latitude = prefs.weatherLatitude,
                longitude = prefs.weatherLongitude,
                locationLabel = prefs.weatherCityLabel
            ).onSuccess { fresh ->
                _weather.value = fresh
            }.onFailure { err ->
                _weather.value = _weather.value.copy(
                    isLoading = false,
                    isLiveData = false,
                    conditionLabel = "Sync Unavailable",
                    errorMessage = err.message ?: "Network error"
                )
            }
        }
    }

    fun launchApp(appEntry: InstalledApp) {
        appDiscovery.launchApp(appEntry)
            .onSuccess {
                viewModelScope.launch {
                    settingsRepo.recordAppLaunch(appEntry.packageName)
                }
                _isAppDrawerOpen.value = false
                _drawerSearchQuery.value = ""
            }
            .onFailure {
                postStatus("Unable to launch ${appEntry.label}")
            }
    }

    fun toggleDock(packageName: String) {
        viewModelScope.launch { settingsRepo.toggleDockPackage(packageName) }
    }

    fun toggleFavorite(packageName: String) {
        viewModelScope.launch { settingsRepo.toggleFavoritePackage(packageName) }
    }

    fun setHidden(packageName: String, hidden: Boolean) {
        viewModelScope.launch {
            settingsRepo.setAppHidden(packageName, hidden)
            postStatus(if (hidden) "App hidden from launcher" else "App restored to launcher")
        }
    }

    fun togglePinToCurrentHomePage(packageName: String) {
        val page = _currentHomePage.value
        val alreadyPinned = preferencesFlow.value.homePinnedApps.any {
            it.packageName == packageName && it.pageIndex == page
        }
        viewModelScope.launch {
            if (alreadyPinned) {
                settingsRepo.unpinAppFromHomePage(packageName, page)
            } else {
                settingsRepo.pinAppToHomePage(packageName, page)
            }
        }
    }

    fun toggleGamingTag(packageName: String) {
        viewModelScope.launch { settingsRepo.toggleGamingPackage(packageName) }
    }

    fun openAppInfo(packageName: String) = appDiscovery.openAppInfo(packageName)

    fun uninstallApp(packageName: String) = appDiscovery.requestUninstallApp(packageName)

    fun setTheme(preset: CyberThemePreset) {
        viewModelScope.launch { settingsRepo.setTheme(preset) }
    }

    fun setWallpaper(preset: WallpaperPreset, customUri: String? = null) {
        viewModelScope.launch { settingsRepo.setWallpaper(preset, customUri) }
    }

    fun setWallpaperDim(alpha: Float) {
        viewModelScope.launch { settingsRepo.setWallpaperDim(alpha) }
    }

    fun setIconSize(size: IconSizePreset) {
        viewModelScope.launch { settingsRepo.setIconSize(size) }
    }

    fun setIconStyle(style: AppIconStyle) {
        viewModelScope.launch { settingsRepo.setIconStyle(style) }
    }

    fun setIconPack(packageName: String?) {
        viewModelScope.launch { settingsRepo.setIconPackPackage(packageName) }
    }

    fun setAnimationSpeed(speed: AnimationSpeed) {
        viewModelScope.launch { settingsRepo.setAnimationSpeed(speed) }
    }

    fun setGridDimensions(cols: Int, rows: Int) {
        viewModelScope.launch { settingsRepo.setGridDimensions(cols, rows) }
    }

    fun setHomePageCount(count: Int) {
        viewModelScope.launch { settingsRepo.setHomePageCount(count) }
    }

    fun setDockSettings(show: Boolean, count: Int, showLabels: Boolean) {
        viewModelScope.launch { settingsRepo.setDockSettings(show, count, showLabels) }
    }

    fun setClockSettings(use24Hour: Boolean, showSeconds: Boolean, size: ClockSizePreset) {
        viewModelScope.launch { settingsRepo.setClockSettings(use24Hour, showSeconds, size) }
    }

    fun setWeatherSettings(
        showWidget: Boolean,
        useLive: Boolean,
        city: String,
        lat: Double,
        lon: Double
    ) {
        viewModelScope.launch {
            settingsRepo.setWeatherSettings(showWidget, useLive, city, lat, lon)
            refreshWeather()
        }
    }

    fun setShowHomeTelemetryStrip(show: Boolean) {
        viewModelScope.launch { settingsRepo.setShowHomeTelemetryStrip(show) }
    }

    fun setSearchSettings(
        showRecent: Boolean,
        autoFocus: Boolean,
        searchPackages: Boolean,
        sortOrder: AppSortOrder
    ) {
        viewModelScope.launch {
            settingsRepo.setSearchSettings(showRecent, autoFocus, searchPackages, sortOrder)
        }
    }

    fun exportBackupJson(): String = BackupManager.exportToJson(preferencesFlow.value)

    fun importBackupJson(rawJson: String) {
        BackupManager.importFromJson(rawJson)
            .onSuccess { restored ->
                viewModelScope.launch {
                    settingsRepo.replaceAllPreferences(restored)
                    postStatus("Launcher configuration restored")
                }
            }
            .onFailure { err ->
                postStatus("Restore failed: ${err.message ?: "Invalid JSON"}")
            }
    }

    fun openHomeSettings() = securityProvider.openHomeSettings()
    fun openUsageAccessSettings() = securityProvider.openUsageAccessSettings()
    fun openDeviceSecuritySettings() = securityProvider.openDeviceSecuritySettings()
    fun createRequestDefaultHomeIntent(): Intent = securityProvider.createRequestDefaultHomeIntent()

    fun postStatus(message: String) {
        _statusMessage.value = message
    }

    fun clearStatus() {
        _statusMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        runCatching { getApplication<Application>().unregisterReceiver(batteryReceiver) }
    }

    private data class Quad<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
}
