package com.kalinexus.launcher

import android.app.Application
import com.kalinexus.launcher.data.SettingsRepository
import com.kalinexus.launcher.data.WeatherRepository
import com.kalinexus.launcher.system.AppDiscoveryManager
import com.kalinexus.launcher.system.DeviceTelemetryProvider
import com.kalinexus.launcher.system.SecurityAuditProvider

class KaliNexusApplication : Application() {
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var appDiscoveryManager: AppDiscoveryManager
        private set
    lateinit var telemetryProvider: DeviceTelemetryProvider
        private set
    lateinit var securityAuditProvider: SecurityAuditProvider
        private set
    lateinit var weatherRepository: WeatherRepository
        private set

    override fun onCreate() {
        super.onCreate()
        settingsRepository = SettingsRepository(this)
        appDiscoveryManager = AppDiscoveryManager(this)
        telemetryProvider = DeviceTelemetryProvider(this)
        securityAuditProvider = SecurityAuditProvider(this)
        weatherRepository = WeatherRepository()
    }
}
