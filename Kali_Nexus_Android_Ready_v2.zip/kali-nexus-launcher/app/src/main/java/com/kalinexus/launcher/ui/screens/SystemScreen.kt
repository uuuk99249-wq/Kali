package com.kalinexus.launcher.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kalinexus.launcher.system.DeviceTelemetryProvider
import com.kalinexus.launcher.ui.components.CyberSurfaceCard
import com.kalinexus.launcher.ui.components.SectionHeader
import com.kalinexus.launcher.ui.theme.LocalKaliPalette
import com.kalinexus.launcher.viewmodel.LauncherUiState

@Composable
fun SystemScreen(
    state: LauncherUiState,
    onRefreshTelemetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current
    val tel = state.telemetry

    val usedRam = (tel.totalRamBytes - tel.availRamBytes).coerceAtLeast(0L)
    val ramProgress = if (tel.totalRamBytes > 0L) {
        (usedRam.toFloat() / tel.totalRamBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val usedStorage = (tel.totalStorageBytes - tel.availStorageBytes).coerceAtLeast(0L)
    val storageProgress = if (tel.totalStorageBytes > 0L) {
        (usedStorage.toFloat() / tel.totalStorageBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "System Hardware",
                subtitle = "GENUINE ANDROID PLATFORM TELEMETRY",
                trailing = {
                    IconButton(onClick = onRefreshTelemetry) {
                        Icon(
                            imageVector = Icons.Outlined.Refresh,
                            contentDescription = "Refresh Hardware Telemetry",
                            tint = palette.primaryAccent
                        )
                    }
                }
            )
        }

        item {
            CyberSurfaceCard(highlightBorder = true) {
                Text(
                    text = "MEMORY & STORAGE",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("RAM Available", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                    Text(
                        text = "${DeviceTelemetryProvider.formatBytesToMbOrGb(tel.availRamBytes)} / ${DeviceTelemetryProvider.formatBytesToMbOrGb(tel.totalRamBytes)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.textPrimary
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { ramProgress },
                    modifier = Modifier.fillMaxWidth().height(5.dp),
                    color = palette.primaryAccent,
                    trackColor = palette.graphiteDeep
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Internal Storage Available", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                    Text(
                        text = "${DeviceTelemetryProvider.formatBytesToGb(tel.availStorageBytes)} / ${DeviceTelemetryProvider.formatBytesToGb(tel.totalStorageBytes)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.textPrimary
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { storageProgress },
                    modifier = Modifier.fillMaxWidth().height(5.dp),
                    color = palette.secondaryAccent,
                    trackColor = palette.graphiteDeep
                )
            }
        }

        item {
            CyberSurfaceCard {
                Text(
                    text = "DEVICE IDENTITY & ANDROID OS",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent
                )
                Spacer(modifier = Modifier.height(8.dp))
                TelemetryRow("Manufacturer", tel.manufacturer)
                TelemetryRow("Model", tel.model)
                TelemetryRow("Brand / Device", "${tel.brand} (${tel.deviceCodename})")
                TelemetryRow("Android Version", "Android ${tel.androidVersion}")
                TelemetryRow("API Level", "API ${tel.apiLevel}")
                TelemetryRow("Security Patch", tel.securityPatch)
                TelemetryRow("Build ID", tel.buildId)
            }
        }

        item {
            CyberSurfaceCard {
                Text(
                    text = "POWER, NETWORK & COMPUTE",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent
                )
                Spacer(modifier = Modifier.height(8.dp))
                TelemetryRow("Battery Level", "${tel.batteryPercent}% (${tel.batterySource})")
                TelemetryRow("Charging Status", if (tel.isCharging) "Charging" else "Discharging")
                TelemetryRow("Battery Health", tel.batteryHealth)
                TelemetryRow(
                    "Battery Temperature",
                    tel.batteryTempCelsius?.let { String.format("%.1f °C", it) } ?: "Not exposed"
                )
                TelemetryRow(
                    "Network Connection",
                    if (tel.networkConnected) "${tel.networkType}${if (tel.isVpnActive) " + VPN" else ""}" else "Offline"
                )
                TelemetryRow("Metered Link", if (tel.isMetered) "Yes" else "No")
                TelemetryRow("CPU Logical Cores", "${tel.cpuCores}")
                TelemetryRow("Supported ABIs", tel.supportedAbis.joinToString(", "))
                TelemetryRow("Hardware / SoC", tel.cpuInfoLabel ?: tel.hardwareBoard)
                TelemetryRow(
                    "Live CPU Clocks",
                    if (tel.cpuCurrentFreqsMhz.isNotEmpty()) {
                        tel.cpuCurrentFreqsMhz.joinToString(" / ") { "${it}MHz" }
                    } else {
                        "Restricted by Android SELinux"
                    }
                )
                TelemetryRow("Thermal Status", tel.thermalStatusLabel)
            }
        }

        item {
            CyberSurfaceCard {
                Text(
                    text = "KALI NEXUS ECOSYSTEM PROFILE (CONCEPTUAL SPEC)",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.warningAmber
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Fictional KALI NEXUS OS ecosystem metadata is kept strictly separate from live Android hardware readings above.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                TelemetryRow("Ecosystem Shell", "KALI NEXUS OS — Cyber Edition")
                TelemetryRow("Shell Module", "Nexus Home Surface v1.0")
                TelemetryRow("Design Architecture", "Zero-Root Jetpack Compose")
            }
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String) {
    val palette = LocalKaliPalette.current
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary,
                modifier = Modifier.weight(0.45f)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                color = palette.textPrimary,
                modifier = Modifier.weight(0.55f)
            )
        }
        HorizontalDivider(color = palette.hairlineBorder.copy(alpha = 0.6f))
    }
}
