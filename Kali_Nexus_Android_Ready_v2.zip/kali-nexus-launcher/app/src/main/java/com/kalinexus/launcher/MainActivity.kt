package com.kalinexus.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kalinexus.launcher.model.InstalledApp
import com.kalinexus.launcher.model.MainSection
import com.kalinexus.launcher.ui.components.AppActionDialog
import com.kalinexus.launcher.ui.components.CyberWallpaperBackground
import com.kalinexus.launcher.ui.components.KaliNexusBottomNav
import com.kalinexus.launcher.ui.screens.AppDrawerSheet
import com.kalinexus.launcher.ui.screens.GamingScreen
import com.kalinexus.launcher.ui.screens.HomeScreen
import com.kalinexus.launcher.ui.screens.SecurityScreen
import com.kalinexus.launcher.ui.screens.SettingsScreen
import com.kalinexus.launcher.ui.screens.SystemScreen
import com.kalinexus.launcher.ui.theme.KaliNexusTheme
import com.kalinexus.launcher.viewmodel.LauncherViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            KaliNexusRoot(
                viewModel = viewModel,
                state = state
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME) || intent.action == Intent.ACTION_MAIN) {
            viewModel.onHomeButtonPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshTelemetry()
        viewModel.refreshRecentApps()
    }
}

@Composable
private fun KaliNexusRoot(
    viewModel: LauncherViewModel,
    state: com.kalinexus.launcher.viewmodel.LauncherUiState
) {
    val prefs = state.preferences
    val animMillis = prefs.animationSpeed.durationMillis
    val snackbarHostState = remember { SnackbarHostState() }
    var selectedAppForMenu by remember { mutableStateOf<InstalledApp?>(null) }

    val roleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshTelemetry()
    }

    val requestDefaultHome: () -> Unit = {
        runCatching {
            roleLauncher.launch(viewModel.createRequestDefaultHomeIntent())
        }.onFailure {
            viewModel.openHomeSettings()
        }
    }

    LaunchedEffect(state.statusBannerMessage) {
        val message = state.statusBannerMessage
        if (!message.isNullOrBlank()) {
            snackbarHostState.showSnackbar(message)
            viewModel.clearStatus()
        }
    }

    // Standard Android launcher behavior: Back closes overlays or returns to HOME page 0, never exits launcher.
    BackHandler(enabled = true) {
        when {
            selectedAppForMenu != null -> selectedAppForMenu = null
            state.isAppDrawerOpen -> viewModel.closeAppDrawer()
            state.currentSection != MainSection.HOME -> viewModel.selectSection(MainSection.HOME)
            state.currentHomePage != 0 -> viewModel.setHomePage(0)
        }
    }

    KaliNexusTheme(preset = prefs.themePreset) {
        Box(modifier = Modifier.fillMaxSize()) {
            CyberWallpaperBackground(
                preset = prefs.wallpaperPreset,
                customWallpaperUri = prefs.customWallpaperUri,
                dimAlpha = prefs.wallpaperDimAlpha
            )

            Scaffold(
                containerColor = Color.Transparent,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!state.isAppDrawerOpen) {
                        KaliNexusBottomNav(
                            currentSection = state.currentSection,
                            onSelectSection = viewModel::selectSection
                        )
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = innerPadding.calculateBottomPadding())
                ) {
                    AnimatedContent(
                        targetState = state.currentSection,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(animMillis)) togetherWith
                                fadeOut(animationSpec = tween(animMillis))
                        },
                        label = "MainSectionTransition",
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) { section ->
                        when (section) {
                            MainSection.HOME -> HomeScreen(
                                state = state,
                                onOpenDrawer = viewModel::openAppDrawer,
                                onLaunchApp = viewModel::launchApp,
                                onLongPressApp = { selectedAppForMenu = it },
                                onPageChanged = viewModel::setHomePage,
                                onRefreshWeather = viewModel::refreshWeather,
                                onNavigateSection = viewModel::selectSection,
                                onSetDefaultHome = requestDefaultHome,
                                onTogglePinToPage = viewModel::togglePinToCurrentHomePage,
                                onSetGrid = viewModel::setGridDimensions,
                                onToggleTelemetryStrip = viewModel::setShowHomeTelemetryStrip
                            )
                            MainSection.SYSTEM -> SystemScreen(
                                state = state,
                                onRefreshTelemetry = viewModel::refreshTelemetry
                            )
                            MainSection.SECURITY -> SecurityScreen(
                                state = state,
                                onOpenSecuritySettings = viewModel::openDeviceSecuritySettings,
                                onSetDefaultHome = requestDefaultHome,
                                onOpenUsageAccess = viewModel::openUsageAccessSettings,
                                onOpenAppInfo = viewModel::openAppInfo
                            )
                            MainSection.GAMING -> GamingScreen(
                                state = state,
                                onLaunchApp = viewModel::launchApp,
                                onLongPressApp = { selectedAppForMenu = it },
                                onToggleGamingTag = viewModel::toggleGamingTag
                            )
                            MainSection.SETTINGS -> SettingsScreen(
                                state = state,
                                onSetDefaultHome = requestDefaultHome,
                                onSelectTheme = viewModel::setTheme,
                                onSelectWallpaper = viewModel::setWallpaper,
                                onSetWallpaperDim = viewModel::setWallpaperDim,
                                onSetIconSize = viewModel::setIconSize,
                                onSetIconStyle = viewModel::setIconStyle,
                                onSetIconPack = viewModel::setIconPack,
                                onSetAnimationSpeed = viewModel::setAnimationSpeed,
                                onSetGrid = viewModel::setGridDimensions,
                                onSetHomePages = viewModel::setHomePageCount,
                                onSetDock = viewModel::setDockSettings,
                                onSetClock = viewModel::setClockSettings,
                                onSetWeather = viewModel::setWeatherSettings,
                                onSetSearchSettings = viewModel::setSearchSettings,
                                onUnhideApp = { pkg -> viewModel.setHidden(pkg, false) },
                                onExportBackupJson = viewModel::exportBackupJson,
                                onImportBackupJson = viewModel::importBackupJson,
                                onNotify = viewModel::postStatus
                            )
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = state.isAppDrawerOpen,
                enter = slideInVertically(
                    animationSpec = tween(animMillis),
                    initialOffsetY = { it / 2 }
                ) + fadeIn(animationSpec = tween(animMillis)),
                exit = slideOutVertically(
                    animationSpec = tween(animMillis),
                    targetOffsetY = { it / 2 }
                ) + fadeOut(animationSpec = tween(animMillis))
            ) {
                AppDrawerSheet(
                    state = state,
                    onClose = viewModel::closeAppDrawer,
                    onQueryChange = viewModel::updateSearchQuery,
                    onToggleSort = { order ->
                        viewModel.setSearchSettings(
                            showRecent = prefs.showRecentApps,
                            autoFocus = prefs.autoFocusDrawerSearch,
                            searchPackages = prefs.searchPackageNames,
                            sortOrder = order
                        )
                    },
                    onLaunchApp = viewModel::launchApp,
                    onLongPressApp = { selectedAppForMenu = it },
                    onUnhideApp = { pkg -> viewModel.setHidden(pkg, false) },
                    onOpenUsageAccess = viewModel::openUsageAccessSettings
                )
            }

            selectedAppForMenu?.let { app ->
                val isPinned = prefs.homePinnedApps.any {
                    it.packageName == app.packageName && it.pageIndex == state.currentHomePage
                }
                AppActionDialog(
                    app = app,
                    isInDock = app.packageName in prefs.dockPackages,
                    isFavorite = app.packageName in prefs.favoritePackages,
                    isPinnedToCurrentPage = isPinned,
                    isTaggedGame = app.isGameCategory || app.packageName in prefs.gamingPackages,
                    currentHomePage = state.currentHomePage,
                    onDismiss = { selectedAppForMenu = null },
                    onLaunch = { viewModel.launchApp(app) },
                    onToggleDock = { viewModel.toggleDock(app.packageName) },
                    onToggleFavorite = { viewModel.toggleFavorite(app.packageName) },
                    onTogglePinHome = { viewModel.togglePinToCurrentHomePage(app.packageName) },
                    onToggleGameTag = { viewModel.toggleGamingTag(app.packageName) },
                    onHideApp = { viewModel.setHidden(app.packageName, true) },
                    onAppInfo = { viewModel.openAppInfo(app.packageName) },
                    onUninstall = { viewModel.uninstallApp(app.packageName) }
                )
            }
        }
    }
}
