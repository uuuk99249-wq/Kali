package com.kalinexus.launcher.model

import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.serialization.Serializable

enum class MainSection(val label: String) {
    HOME("HOME"),
    SYSTEM("SYSTEM"),
    SECURITY("SECURITY"),
    GAMING("GAMING"),
    SETTINGS("SETTINGS")
}

@Serializable
enum class CyberThemePreset(val displayName: String, val primaryHex: Long, val secondaryHex: Long) {
    CYBER_CYAN("Cyber Cyan", 0xFF00E5FF, 0xFF00A3FF),
    ELECTRIC_COBALT("Electric Cobalt", 0xFF2979FF, 0xFF00D4FF),
    STEALTH_EMERALD("Stealth Emerald", 0xFF00E676, 0xFF00BFA5),
    CARBON_MONOCHROME("Carbon Monochrome", 0xFFE2E8F0, 0xFF94A3B8)
}

@Serializable
enum class WallpaperPreset(val displayName: String) {
    OBSIDIAN_GRID("Obsidian Grid"),
    NEURAL_CIRCUIT("Neural Circuit"),
    COBALT_HORIZON("Cobalt Horizon"),
    PURE_BLACK("Stealth Pure Black"),
    CUSTOM_IMAGE("Custom Gallery Image")
}

@Serializable
enum class IconSizePreset(val displayName: String, val dpValue: Int) {
    COMPACT("Compact", 44),
    STANDARD("Standard", 52),
    LARGE("Large", 60)
}

@Serializable
enum class AnimationSpeed(val displayName: String, val durationMillis: Int) {
    SMOOTH("Smooth", 300),
    SNAPPY("Snappy", 160),
    REDUCED("Reduced Motion", 40)
}

@Serializable
enum class ClockSizePreset(val displayName: String, val spValue: Int) {
    COMPACT("Compact", 44),
    STANDARD("Standard", 58),
    LARGE("Large", 72)
}

@Serializable
enum class AppIconStyle(val displayName: String) {
    ORIGINAL("System Original"),
    CYBER_FRAME("Cyber Framed"),
    MONOCHROME_TINT("Monochrome Cyber Tint")
}

@Serializable
enum class AppSortOrder(val displayName: String) {
    ALPHA_ASC("Name (A–Z)"),
    ALPHA_DESC("Name (Z–A)")
}

@Serializable
data class HomePinnedApp(
    val packageName: String,
    val pageIndex: Int = 0
)

@Serializable
data class LauncherPreferences(
    val themePreset: CyberThemePreset = CyberThemePreset.CYBER_CYAN,
    val wallpaperPreset: WallpaperPreset = WallpaperPreset.OBSIDIAN_GRID,
    val customWallpaperUri: String? = null,
    val wallpaperDimAlpha: Float = 0.45f,
    val iconSize: IconSizePreset = IconSizePreset.STANDARD,
    val iconStyle: AppIconStyle = AppIconStyle.CYBER_FRAME,
    val selectedIconPackPackage: String? = null,
    val animationSpeed: AnimationSpeed = AnimationSpeed.SMOOTH,
    val gridColumns: Int = 4,
    val gridRows: Int = 5,
    val homePageCount: Int = 2,
    val showDock: Boolean = true,
    val dockCount: Int = 5,
    val showDockLabels: Boolean = false,
    val use24HourClock: Boolean = true,
    val showClockSeconds: Boolean = false,
    val clockSize: ClockSizePreset = ClockSizePreset.STANDARD,
    val showWeatherWidget: Boolean = true,
    val weatherCityLabel: String = "Local Sector",
    val weatherLatitude: Double = 37.7749,
    val weatherLongitude: Double = -122.4194,
    val useLiveWeather: Boolean = false,
    val showHomeTelemetryStrip: Boolean = true,
    val showRecentApps: Boolean = true,
    val autoFocusDrawerSearch: Boolean = false,
    val searchPackageNames: Boolean = false,
    val sortOrder: AppSortOrder = AppSortOrder.ALPHA_ASC,
    val dockPackages: List<String> = emptyList(),
    val favoritePackages: Set<String> = emptySet(),
    val hiddenPackages: Set<String> = emptySet(),
    val gamingPackages: Set<String> = emptySet(),
    val homePinnedApps: List<HomePinnedApp> = emptyList(),
    val localRecentPackages: List<String> = emptyList()
)

@Serializable
data class LauncherBackupPayload(
    val schemaVersion: Int = 1,
    val exportedAtEpochMs: Long,
    val appVersion: String,
    val preferences: LauncherPreferences
)

data class InstalledApp(
    val packageName: String,
    val activityName: String,
    val label: String,
    val isSystemApp: Boolean,
    val isGameCategory: Boolean,
    val firstInstallTime: Long,
    val lastUpdateTime: Long,
    val icon: ImageBitmap? = null
)

data class IconPackInfo(
    val packageName: String,
    val label: String
)

data class DeviceTelemetry(
    val manufacturer: String = "Unknown",
    val model: String = "Unknown",
    val brand: String = "Unknown",
    val deviceCodename: String = "Unknown",
    val hardwareBoard: String = "Unknown",
    val androidVersion: String = "Unknown",
    val apiLevel: Int = 0,
    val securityPatch: String = "Unavailable",
    val buildId: String = "Unknown",
    val availRamBytes: Long = 0L,
    val totalRamBytes: Long = 0L,
    val availStorageBytes: Long = 0L,
    val totalStorageBytes: Long = 0L,
    val batteryPercent: Int = 0,
    val isCharging: Boolean = false,
    val batterySource: String = "Battery",
    val batteryHealth: String = "Unknown",
    val batteryTempCelsius: Float? = null,
    val networkConnected: Boolean = false,
    val networkType: String = "Offline",
    val isVpnActive: Boolean = false,
    val isMetered: Boolean = false,
    val cpuCores: Int = 0,
    val supportedAbis: List<String> = emptyList(),
    val cpuInfoLabel: String? = null,
    val cpuCurrentFreqsMhz: List<Int> = emptyList(),
    val thermalStatusLabel: String = "Unavailable"
)

data class WeatherState(
    val temperatureCelsius: Double? = null,
    val conditionLabel: String = "Offline Stand-by",
    val windKmh: Double? = null,
    val locationLabel: String = "Local Sector",
    val isLiveData: Boolean = false,
    val isLoading: Boolean = false,
    val lastUpdatedEpochMs: Long? = null,
    val errorMessage: String? = null
)

data class SecurityOverview(
    val isDeviceLockSecure: Boolean = false,
    val hasUsageStatsPermission: Boolean = false,
    val isDefaultHomeLauncher: Boolean = false,
    val isVpnActive: Boolean = false,
    val totalInstalledLaunchableApps: Int = 0,
    val userInstalledAppsCount: Int = 0,
    val recentlyInstalledApps: List<InstalledApp> = emptyList()
)
