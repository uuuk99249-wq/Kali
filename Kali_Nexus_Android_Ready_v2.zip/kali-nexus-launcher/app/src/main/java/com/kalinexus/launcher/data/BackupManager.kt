package com.kalinexus.launcher.data

import com.kalinexus.launcher.BuildConfig
import com.kalinexus.launcher.model.LauncherBackupPayload
import com.kalinexus.launcher.model.LauncherPreferences
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

object BackupManager {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    fun exportToJson(preferences: LauncherPreferences): String {
        val payload = LauncherBackupPayload(
            schemaVersion = 1,
            exportedAtEpochMs = System.currentTimeMillis(),
            appVersion = BuildConfig.VERSION_NAME,
            preferences = preferences
        )
        return json.encodeToString(payload)
    }

    fun importFromJson(rawJson: String): Result<LauncherPreferences> {
        return runCatching {
            val trimmed = rawJson.trim()
            require(trimmed.isNotEmpty()) { "Backup file is empty." }
            val payload = json.decodeFromString<LauncherBackupPayload>(trimmed)
            require(payload.schemaVersion >= 1) { "Unsupported backup schema version." }
            payload.preferences.copy(
                gridColumns = payload.preferences.gridColumns.coerceIn(4, 5),
                gridRows = payload.preferences.gridRows.coerceIn(4, 6),
                homePageCount = payload.preferences.homePageCount.coerceIn(1, 5),
                dockCount = payload.preferences.dockCount.coerceIn(4, 6),
                wallpaperDimAlpha = payload.preferences.wallpaperDimAlpha.coerceIn(0.1f, 0.9f)
            )
        }
    }
}
