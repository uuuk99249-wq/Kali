package com.kalinexus.launcher.ui.components

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kalinexus.launcher.model.AppIconStyle
import com.kalinexus.launcher.model.InstalledApp
import com.kalinexus.launcher.model.MainSection
import com.kalinexus.launcher.model.WallpaperPreset
import com.kalinexus.launcher.ui.theme.LocalKaliPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun CyberWallpaperBackground(
    preset: WallpaperPreset,
    customWallpaperUri: String?,
    dimAlpha: Float,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current
    val context = LocalContext.current

    val customBitmap by produceState<ImageBitmap?>(initialValue = null, customWallpaperUri, preset) {
        value = if (preset == WallpaperPreset.CUSTOM_IMAGE && !customWallpaperUri.isNullOrBlank()) {
            withContext(Dispatchers.IO) {
                runCatching {
                    val uri = Uri.parse(customWallpaperUri)
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        BitmapFactory.decodeStream(stream)?.asImageBitmap()
                    }
                }.getOrNull()
            }
        } else {
            null
        }
    }

    Box(modifier = modifier.fillMaxSize().background(palette.voidBlack)) {
        if (preset == WallpaperPreset.CUSTOM_IMAGE && customBitmap != null) {
            Image(
                bitmap = customBitmap!!,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = dimAlpha))
            )
        } else {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                when (preset) {
                    WallpaperPreset.PURE_BLACK -> {
                        drawRect(color = Color(0xFF030406))
                    }
                    WallpaperPreset.OBSIDIAN_GRID, WallpaperPreset.CUSTOM_IMAGE -> {
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF05080D),
                                    Color(0xFF030507),
                                    Color(0xFF060B12)
                                )
                            )
                        )
                        val step = 64.dp.toPx()
                        var x = 0f
                        while (x < w) {
                            drawLine(
                                color = palette.primaryAccent.copy(alpha = 0.045f),
                                start = Offset(x, 0f),
                                end = Offset(x, h),
                                strokeWidth = 1f
                            )
                            x += step
                        }
                        var y = 0f
                        while (y < h) {
                            drawLine(
                                color = palette.primaryAccent.copy(alpha = 0.045f),
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1f
                            )
                            y += step
                        }
                    }
                    WallpaperPreset.NEURAL_CIRCUIT -> {
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    palette.secondaryAccent.copy(alpha = 0.14f),
                                    Color(0xFF04070B)
                                ),
                                center = Offset(w * 0.5f, h * 0.28f),
                                radius = w * 0.9f
                            )
                        )
                        val spacing = 96.dp.toPx()
                        var y = spacing
                        while (y < h) {
                            drawLine(
                                color = palette.primaryAccent.copy(alpha = 0.07f),
                                start = Offset(0f, y),
                                end = Offset(w * 0.35f, y),
                                strokeWidth = 1.5f
                            )
                            drawLine(
                                color = palette.primaryAccent.copy(alpha = 0.07f),
                                start = Offset(w * 0.35f, y),
                                end = Offset(w * 0.45f, y - 24.dp.toPx()),
                                strokeWidth = 1.5f
                            )
                            drawLine(
                                color = palette.primaryAccent.copy(alpha = 0.07f),
                                start = Offset(w * 0.45f, y - 24.dp.toPx()),
                                end = Offset(w, y - 24.dp.toPx()),
                                strokeWidth = 1.5f
                            )
                            y += spacing
                        }
                    }
                    WallpaperPreset.COBALT_HORIZON -> {
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF040608),
                                    Color(0xFF071324),
                                    Color(0xFF030508)
                                )
                            )
                        )
                        drawLine(
                            color = palette.primaryAccent.copy(alpha = 0.18f),
                            start = Offset(0f, h * 0.56f),
                            end = Offset(w, h * 0.56f),
                            strokeWidth = 2f
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CyberSurfaceCard(
    modifier: Modifier = Modifier,
    highlightBorder: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val palette = LocalKaliPalette.current
    val borderColor = if (highlightBorder) {
        palette.primaryAccent.copy(alpha = 0.45f)
    } else {
        palette.hairlineBorder
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = palette.graphiteSurface.copy(alpha = 0.92f),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            content = content
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null
) {
    val palette = LocalKaliPalette.current
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = palette.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = palette.primaryAccent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (trailing != null) {
            Spacer(modifier = Modifier.width(12.dp))
            trailing()
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIconTile(
    app: InstalledApp,
    iconSize: Dp,
    iconStyle: AppIconStyle,
    showLabel: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current
    val haptic = LocalHapticFeedback.current

    val monochromeFilter = if (iconStyle == AppIconStyle.MONOCHROME_TINT) {
        val matrix = ColorMatrix().apply { setToSaturation(0.15f) }
        ColorFilter.colorMatrix(matrix)
    } else {
        null
    }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                }
            )
            .padding(vertical = 6.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(iconSize)
                .then(
                    when (iconStyle) {
                        AppIconStyle.CYBER_FRAME -> Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.graphiteElevated.copy(alpha = 0.85f))
                            .border(
                                1.dp,
                                palette.hairlineBorder.copy(alpha = 0.9f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(6.dp)
                        AppIconStyle.MONOCHROME_TINT -> Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.graphiteDeep)
                            .border(
                                1.dp,
                                palette.primaryAccent.copy(alpha = 0.32f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(6.dp)
                        AppIconStyle.ORIGINAL -> Modifier
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            if (app.icon != null) {
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    colorFilter = monochromeFilter,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Outlined.Apps,
                    contentDescription = app.label,
                    tint = palette.primaryAccent,
                    modifier = Modifier.size(iconSize * 0.55f)
                )
            }

            if (isFavorite) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(7.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(palette.primaryAccent)
                )
            }
        }

        if (showLabel) {
            Spacer(modifier = Modifier.height(5.dp))
            Text(
                text = app.label,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.5.sp),
                color = palette.textPrimary,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun KaliNexusBottomNav(
    currentSection: MainSection,
    onSelectSection: (MainSection) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = palette.graphiteDeep.copy(alpha = 0.96f),
        border = BorderStroke(1.dp, palette.hairlineBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MainSection.entries.forEach { section ->
                val selected = section == currentSection
                val icon = when (section) {
                    MainSection.HOME -> Icons.Outlined.Home
                    MainSection.SYSTEM -> Icons.Outlined.Memory
                    MainSection.SECURITY -> Icons.Outlined.Security
                    MainSection.GAMING -> Icons.Outlined.SportsEsports
                    MainSection.SETTINGS -> Icons.Outlined.Settings
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (selected) palette.primaryAccent.copy(alpha = 0.12f)
                            else Color.Transparent
                        )
                        .clickable { onSelectSection(section) }
                        .padding(vertical = 7.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = section.label,
                        tint = if (selected) palette.primaryAccent else palette.textMuted,
                        modifier = Modifier.size(19.dp)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = section.label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 9.5.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                        ),
                        color = if (selected) palette.primaryAccent else palette.textMuted,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun AppActionDialog(
    app: InstalledApp,
    isInDock: Boolean,
    isFavorite: Boolean,
    isPinnedToCurrentPage: Boolean,
    isTaggedGame: Boolean,
    currentHomePage: Int,
    onDismiss: () -> Unit,
    onLaunch: () -> Unit,
    onToggleDock: () -> Unit,
    onToggleFavorite: () -> Unit,
    onTogglePinHome: () -> Unit,
    onToggleGameTag: () -> Unit,
    onHideApp: () -> Unit,
    onAppInfo: () -> Unit,
    onUninstall: () -> Unit
) {
    val palette = LocalKaliPalette.current

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.graphiteSurface,
        titleContentColor = palette.textPrimary,
        textContentColor = palette.textSecondary,
        title = {
            Column {
                Text(
                    text = app.label,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = app.packageName,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ActionMenuRow(
                    icon = Icons.Outlined.Apps,
                    label = "Open Application",
                    onClick = { onLaunch(); onDismiss() }
                )
                ActionMenuRow(
                    icon = Icons.Outlined.PushPin,
                    label = if (isInDock) "Remove from Dock" else "Pin to Dock",
                    onClick = { onToggleDock(); onDismiss() }
                )
                ActionMenuRow(
                    icon = Icons.Outlined.Home,
                    label = if (isPinnedToCurrentPage) {
                        "Remove from Home Page ${currentHomePage + 1}"
                    } else {
                        "Pin to Home Page ${currentHomePage + 1}"
                    },
                    onClick = { onTogglePinHome(); onDismiss() }
                )
                ActionMenuRow(
                    icon = if (isFavorite) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                    label = if (isFavorite) "Remove from Favorites" else "Add to Favorites",
                    onClick = { onToggleFavorite(); onDismiss() }
                )
                ActionMenuRow(
                    icon = Icons.Outlined.SportsEsports,
                    label = if (isTaggedGame) "Remove from Gaming Hub" else "Add to Gaming Hub",
                    onClick = { onToggleGameTag(); onDismiss() }
                )
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 4.dp),
                    color = palette.hairlineBorder
                )
                ActionMenuRow(
                    icon = Icons.Outlined.VisibilityOff,
                    label = "Hide from Launcher",
                    onClick = { onHideApp(); onDismiss() }
                )
                ActionMenuRow(
                    icon = Icons.Outlined.Info,
                    label = "App Info",
                    onClick = { onAppInfo(); onDismiss() }
                )
                if (!app.isSystemApp) {
                    ActionMenuRow(
                        icon = Icons.Outlined.DeleteOutline,
                        label = "Uninstall",
                        tint = palette.alertRed,
                        onClick = { onUninstall(); onDismiss() }
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = palette.primaryAccent)
            }
        }
    )
}

@Composable
private fun ActionMenuRow(
    icon: ImageVector,
    label: String,
    tint: Color? = null,
    onClick: () -> Unit
) {
    val palette = LocalKaliPalette.current
    val resolvedTint = tint ?: palette.textPrimary

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (tint != null) tint else palette.primaryAccent,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = resolvedTint
        )
    }
}
