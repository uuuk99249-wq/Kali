package com.kalinexus.launcher.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SortByAlpha
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kalinexus.launcher.model.AppSortOrder
import com.kalinexus.launcher.model.InstalledApp
import com.kalinexus.launcher.ui.components.AppIconTile
import com.kalinexus.launcher.ui.theme.LocalKaliPalette
import com.kalinexus.launcher.viewmodel.LauncherUiState
import kotlinx.coroutines.launch

@Composable
fun AppDrawerSheet(
    state: LauncherUiState,
    onClose: () -> Unit,
    onQueryChange: (String) -> Unit,
    onToggleSort: (AppSortOrder) -> Unit,
    onLaunchApp: (InstalledApp) -> Unit,
    onLongPressApp: (InstalledApp) -> Unit,
    onUnhideApp: (String) -> Unit,
    onOpenUsageAccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current
    val prefs = state.preferences
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }
    var showHiddenDialog by remember { mutableStateOf(false) }

    LaunchedEffect(prefs.autoFocusDrawerSearch) {
        if (prefs.autoFocusDrawerSearch) {
            runCatching { focusRequester.requestFocus() }
        }
    }

    val indexLetters = remember(state.filteredDrawerApps) {
        state.filteredDrawerApps
            .mapNotNull { it.label.firstOrNull()?.uppercaseChar() }
            .distinct()
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = palette.voidBlack.copy(alpha = 0.96f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Top bar: Search + Sort + Hidden + Close
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = state.drawerSearchQuery,
                    onValueChange = onQueryChange,
                    placeholder = {
                        Text(
                            text = "Search ${state.filteredDrawerApps.size} installed apps",
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textMuted
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = "Search",
                            tint = palette.primaryAccent
                        )
                    },
                    trailingIcon = {
                        if (state.drawerSearchQuery.isNotEmpty()) {
                            IconButton(onClick = { onQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Outlined.Close,
                                    contentDescription = "Clear Search",
                                    tint = palette.textSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.primaryAccent,
                        unfocusedBorderColor = palette.hairlineBorder,
                        focusedContainerColor = palette.graphiteSurface,
                        unfocusedContainerColor = palette.graphiteSurface,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester)
                )

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = {
                        val next = if (prefs.sortOrder == AppSortOrder.ALPHA_ASC) {
                            AppSortOrder.ALPHA_DESC
                        } else {
                            AppSortOrder.ALPHA_ASC
                        }
                        onToggleSort(next)
                    }
                ) {
                    Icon(
                        imageVector = Icons.Outlined.SortByAlpha,
                        contentDescription = "Toggle Sort Order",
                        tint = palette.primaryAccent
                    )
                }

                if (state.hiddenApps.isNotEmpty()) {
                    IconButton(onClick = { showHiddenDialog = true }) {
                        Icon(
                            imageVector = Icons.Outlined.Visibility,
                            contentDescription = "Hidden Apps",
                            tint = palette.textSecondary
                        )
                    }
                }

                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Close Drawer",
                        tint = palette.textPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Favorites Section (only when not searching)
            if (state.drawerSearchQuery.isBlank() && state.favoriteApps.isNotEmpty()) {
                Text(
                    text = "FAVORITES",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 8.dp)
                ) {
                    items(state.favoriteApps, key = { "fav_${it.packageName}" }) { app ->
                        AppIconTile(
                            app = app,
                            iconSize = (prefs.iconSize.dpValue - 4).coerceAtLeast(40).dp,
                            iconStyle = prefs.iconStyle,
                            showLabel = true,
                            isFavorite = true,
                            onClick = { onLaunchApp(app) },
                            onLongClick = { onLongPressApp(app) },
                            modifier = Modifier.width(72.dp)
                        )
                    }
                }
            }

            // Recently Used Section
            if (state.drawerSearchQuery.isBlank() && prefs.showRecentApps) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RECENTLY USED",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.textSecondary
                    )
                    if (!state.securityOverview.hasUsageStatsPermission) {
                        Text(
                            text = "Enable Usage Access",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.primaryAccent,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable(onClick = onOpenUsageAccess)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                if (state.recentApps.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 8.dp)
                    ) {
                        items(state.recentApps, key = { "rec_${it.packageName}" }) { app ->
                            AppIconTile(
                                app = app,
                                iconSize = (prefs.iconSize.dpValue - 4).coerceAtLeast(40).dp,
                                iconStyle = prefs.iconStyle,
                                showLabel = true,
                                isFavorite = app.packageName in prefs.favoritePackages,
                                onClick = { onLaunchApp(app) },
                                onLongClick = { onLongPressApp(app) },
                                modifier = Modifier.width(72.dp)
                            )
                        }
                    }
                }
            }

            // All Applications Grid + Alphabetical Index Rail
            Text(
                text = if (state.drawerSearchQuery.isBlank()) {
                    "APPLICATIONS (${state.filteredDrawerApps.size})"
                } else {
                    "MATCHES (${state.filteredDrawerApps.size})"
                },
                style = MaterialTheme.typography.labelMedium,
                color = palette.textMuted,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (state.filteredDrawerApps.isEmpty()) {
                    Box(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No matching launchable applications found.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textMuted
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        state = gridState,
                        columns = GridCells.Fixed(prefs.gridColumns),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentPadding = PaddingValues(bottom = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(
                            items = state.filteredDrawerApps,
                            key = { "${it.packageName}/${it.activityName}" }
                        ) { app ->
                            AppIconTile(
                                app = app,
                                iconSize = prefs.iconSize.dpValue.dp,
                                iconStyle = prefs.iconStyle,
                                showLabel = true,
                                isFavorite = app.packageName in prefs.favoritePackages,
                                onClick = { onLaunchApp(app) },
                                onLongClick = { onLongPressApp(app) }
                            )
                        }
                    }
                }

                if (indexLetters.size > 3) {
                    Column(
                        modifier = Modifier
                            .width(22.dp)
                            .fillMaxHeight()
                            .padding(vertical = 4.dp),
                        verticalArrangement = Arrangement.SpaceEvenly,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        indexLetters.forEach { ch ->
                            Text(
                                text = ch.toString(),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                                color = palette.textSecondary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .clickable {
                                        val targetIdx = state.filteredDrawerApps.indexOfFirst {
                                            it.label.firstOrNull()?.uppercaseChar() == ch
                                        }
                                        if (targetIdx >= 0) {
                                            scope.launch {
                                                gridState.animateScrollToItem(targetIdx)
                                            }
                                        }
                                    }
                                    .padding(horizontal = 3.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showHiddenDialog) {
        AlertDialog(
            onDismissRequest = { showHiddenDialog = false },
            containerColor = palette.graphiteSurface,
            title = { Text("Hidden Applications", color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.hiddenApps.forEach { app ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = palette.graphiteDeep,
                            border = BorderStroke(1.dp, palette.hairlineBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(app.label, color = palette.textPrimary)
                                    Text(
                                        app.packageName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.textMuted
                                    )
                                }
                                TextButton(onClick = { onUnhideApp(app.packageName) }) {
                                    Text("Restore", color = palette.primaryAccent)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHiddenDialog = false }) {
                    Text("Close", color = palette.primaryAccent)
                }
            }
        )
    }
}
