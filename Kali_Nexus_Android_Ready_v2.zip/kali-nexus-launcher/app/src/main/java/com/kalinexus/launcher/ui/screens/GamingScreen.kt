package com.kalinexus.launcher.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.kalinexus.launcher.model.InstalledApp
import com.kalinexus.launcher.system.DeviceTelemetryProvider
import com.kalinexus.launcher.ui.components.AppIconTile
import com.kalinexus.launcher.ui.components.CyberSurfaceCard
import com.kalinexus.launcher.ui.components.SectionHeader
import com.kalinexus.launcher.ui.theme.LocalKaliPalette
import com.kalinexus.launcher.viewmodel.LauncherUiState

@Composable
fun GamingScreen(
    state: LauncherUiState,
    onLaunchApp: (InstalledApp) -> Unit,
    onLongPressApp: (InstalledApp) -> Unit,
    onToggleGamingTag: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current
    val prefs = state.preferences
    val tel = state.telemetry
    var showAddGameDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Gaming Hub",
                subtitle = "THERMAL HEADROOM & CURATED GAME LAUNCHER",
                trailing = {
                    TextButton(onClick = { showAddGameDialog = true }) {
                        Icon(
                            imageVector = Icons.Outlined.Add,
                            contentDescription = null,
                            tint = palette.primaryAccent
                        )
                        Text("Tag App", color = palette.primaryAccent)
                    }
                }
            )
        }

        item {
            CyberSurfaceCard(highlightBorder = true) {
                Text(
                    text = "LIVE DEVICE READINESS",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ReadinessStat("THERMAL", tel.thermalStatusLabel)
                    ReadinessStat(
                        "FREE RAM",
                        DeviceTelemetryProvider.formatBytesToMbOrGb(tel.availRamBytes)
                    )
                    ReadinessStat("BATTERY", "${tel.batteryPercent}%")
                }
            }
        }

        item {
            CyberSurfaceCard {
                Text(
                    text = "GAME LIBRARY (${state.gamingApps.size})",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent
                )
                Spacer(modifier = Modifier.height(6.dp))
                if (state.gamingApps.isEmpty()) {
                    Text(
                        text = "No apps tagged as CATEGORY_GAME by Android were found. Tap 'Tag App' above or long-press any app to add it to Gaming Hub.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textSecondary
                    )
                } else {
                    val rows = state.gamingApps.chunked(prefs.gridColumns)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        rows.forEach { rowApps ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                rowApps.forEach { game ->
                                    AppIconTile(
                                        app = game,
                                        iconSize = prefs.iconSize.dpValue.dp,
                                        iconStyle = prefs.iconStyle,
                                        showLabel = true,
                                        isFavorite = game.packageName in prefs.favoritePackages,
                                        onClick = { onLaunchApp(game) },
                                        onLongClick = { onLongPressApp(game) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                repeat(prefs.gridColumns - rowApps.size) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            CyberSurfaceCard {
                Text(
                    text = "FUTURE MODULES (ROADMAP PLACEHOLDERS)",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.warningAmber
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "[PLANNED MODULE] Do-Not-Disturb Auto-Trigger on Launch",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.textPrimary
                )
                Text(
                    text = "Automatically request NotificationManager interruption filter when launching tagged titles.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textMuted
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "[PLANNED MODULE] Frame Time & Thermal History Graph",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.textPrimary
                )
                Text(
                    text = "Session-level thermal state logging without root privileges.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textMuted
                )
            }
        }
    }

    if (showAddGameDialog) {
        AlertDialog(
            onDismissRequest = { showAddGameDialog = false },
            containerColor = palette.graphiteSurface,
            title = { Text("Tag Apps for Gaming Hub", color = palette.textPrimary) },
            text = {
                LazyColumn(
                    modifier = Modifier.height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val candidates = state.allApps.filterNot { it.packageName in prefs.hiddenPackages }
                    items(candidates.size) { index ->
                        val app = candidates[index]
                        val tagged = app.isGameCategory || app.packageName in prefs.gamingPackages
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = palette.graphiteDeep,
                            border = BorderStroke(
                                1.dp,
                                if (tagged) palette.primaryAccent else palette.hairlineBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleGamingTag(app.packageName) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = app.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = if (tagged) "INCLUDED" else "ADD",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (tagged) palette.primaryAccent else palette.textMuted
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddGameDialog = false }) {
                    Text("Done", color = palette.primaryAccent)
                }
            }
        )
    }
}

@Composable
private fun ReadinessStat(label: String, value: String) {
    val palette = LocalKaliPalette.current
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
    }
}
