package com.kalinexus.launcher.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.BatteryStd
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kalinexus.launcher.model.InstalledApp
import com.kalinexus.launcher.model.MainSection
import com.kalinexus.launcher.system.DeviceTelemetryProvider
import com.kalinexus.launcher.ui.components.AppIconTile
import com.kalinexus.launcher.ui.components.CyberSurfaceCard
import com.kalinexus.launcher.ui.theme.LocalKaliPalette
import com.kalinexus.launcher.viewmodel.LauncherUiState
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    state: LauncherUiState,
    onOpenDrawer: () -> Unit,
    onLaunchApp: (InstalledApp) -> Unit,
    onLongPressApp: (InstalledApp) -> Unit,
    onPageChanged: (Int) -> Unit,
    onRefreshWeather: () -> Unit,
    onNavigateSection: (MainSection) -> Unit,
    onSetDefaultHome: () -> Unit,
    onTogglePinToPage: (String) -> Unit,
    onSetGrid: (Int, Int) -> Unit,
    onToggleTelemetryStrip: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current
    val haptic = LocalHapticFeedback.current
    val prefs = state.preferences

    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showHomeMenu by remember { mutableStateOf(false) }
    var showPinAppPicker by remember { mutableStateOf(false) }

    LaunchedEffect(prefs.showClockSeconds) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(if (prefs.showClockSeconds) 1_000L else 15_000L)
        }
    }

    val pagerState = rememberPagerState(
        initialPage = state.currentHomePage.coerceIn(0, (prefs.homePageCount - 1).coerceAtLeast(0)),
        pageCount = { prefs.homePageCount.coerceAtLeast(1) }
    )

    LaunchedEffect(state.currentHomePage) {
        if (pagerState.currentPage != state.currentHomePage &&
            state.currentHomePage in 0 until prefs.homePageCount
        ) {
            pagerState.animateScrollToPage(state.currentHomePage)
        }
    }

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { page ->
            onPageChanged(page)
        }
    }

    val byPackage = remember(state.allApps) { state.allApps.associateBy { it.packageName } }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .pointerInput(Unit) {
                var cumulativeDrag = 0f
                detectVerticalDragGestures(
                    onDragStart = { cumulativeDrag = 0f },
                    onVerticalDrag = { _, dragAmount ->
                        cumulativeDrag += dragAmount
                        if (cumulativeDrag < -90f) {
                            cumulativeDrag = 0f
                            onOpenDrawer()
                        }
                    }
                )
            }
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {},
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    showHomeMenu = true
                }
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            if (!state.securityOverview.isDefaultHomeLauncher) {
                DefaultHomeBanner(
                    onSetDefault = onSetDefaultHome,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) { pageIndex ->
                val pinnedForPage = remember(prefs.homePinnedApps, byPackage, pageIndex, prefs.hiddenPackages) {
                    prefs.homePinnedApps
                        .filter { it.pageIndex == pageIndex }
                        .mapNotNull { byPackage[it.packageName] }
                        .filterNot { it.packageName in prefs.hiddenPackages }
                }

                Column(modifier = Modifier.fillMaxSize()) {
                    if (pageIndex == 0) {
                        ClockAndWeatherHeader(
                            nowMillis = nowMillis,
                            use24Hour = prefs.use24HourClock,
                            showSeconds = prefs.showClockSeconds,
                            clockSizeSp = prefs.clockSize.spValue,
                            showWeather = prefs.showWeatherWidget,
                            weather = state.weather,
                            onRefreshWeather = onRefreshWeather
                        )

                        if (prefs.showHomeTelemetryStrip) {
                            Spacer(modifier = Modifier.height(12.dp))
                            HomeTelemetryStrip(
                                state = state,
                                onOpenSystem = { onNavigateSection(MainSection.SYSTEM) }
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "WORKSPACE PAGE ${pageIndex + 1}",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.primaryAccent
                            )
                            TextButton(onClick = { showPinAppPicker = true }) {
                                Icon(
                                    imageVector = Icons.Outlined.Add,
                                    contentDescription = null,
                                    tint = palette.primaryAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Pin App", color = palette.primaryAccent)
                            }
                        }
                    }

                    if (pinnedForPage.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(
                                        1.dp,
                                        palette.hairlineBorder.copy(alpha = 0.7f),
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { showPinAppPicker = true }
                                    .padding(horizontal = 20.dp, vertical = 14.dp)
                            ) {
                                Text(
                                    text = if (pageIndex == 0) "Workspace Clear" else "Empty Workspace Page",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.textSecondary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Long-press background to customize or tap to pin apps",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = palette.textMuted
                                )
                            }
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(prefs.gridColumns),
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentPadding = PaddingValues(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(pinnedForPage, key = { "${pageIndex}_${it.packageName}" }) { app ->
                                AppIconTile(
                                    app = app,
                                    iconSize = prefs.iconSize.dpValue.dp,
                                    iconStyle = prefs.iconStyle,
                                    showLabel = true,
                                    isFavorite = app.packageName in prefs.favoritePackages,
                                    onClick = { onLaunchApp(app) },
                                    onLongClick = { onLongPressApp(app) }
                                )
                            }
                        }
                    }
                }
            }

            // Home Page Indicators + Swipe Drawer Trigger
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(prefs.homePageCount) { idx ->
                        val active = idx == pagerState.currentPage
                        Box(
                            modifier = Modifier
                                .width(if (active) 20.dp else 7.dp)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    if (active) palette.primaryAccent else palette.hairlineBorder
                                )
                        )
                    }
                }

                Surface(
                    onClick = onOpenDrawer,
                    shape = RoundedCornerShape(8.dp),
                    color = palette.graphiteSurface.copy(alpha = 0.9f),
                    border = BorderStroke(1.dp, palette.hairlineBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Apps,
                            contentDescription = "Open App Drawer",
                            tint = palette.primaryAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ALL APPS",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textPrimary
                        )
                    }
                }
            }

            // Application Dock
            if (prefs.showDock && state.dockApps.isNotEmpty()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = palette.graphiteSurface.copy(alpha = 0.9f),
                    border = BorderStroke(1.dp, palette.hairlineBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        state.dockApps.forEach { app ->
                            AppIconTile(
                                app = app,
                                iconSize = (prefs.iconSize.dpValue - 4).coerceAtLeast(40).dp,
                                iconStyle = prefs.iconStyle,
                                showLabel = prefs.showDockLabels,
                                isFavorite = false,
                                onClick = { onLaunchApp(app) },
                                onLongClick = { onLongPressApp(app) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showHomeMenu) {
        HomeCustomizationDialog(
            currentColumns = prefs.gridColumns,
            currentRows = prefs.gridRows,
            showTelemetryStrip = prefs.showHomeTelemetryStrip,
            onDismiss = { showHomeMenu = false },
            onPinApps = { showHomeMenu = false; showPinAppPicker = true },
            onOpenWallpapers = { showHomeMenu = false; onNavigateSection(MainSection.SETTINGS) },
            onSetGrid = onSetGrid,
            onToggleTelemetry = onToggleTelemetryStrip,
            onOpenSettings = { showHomeMenu = false; onNavigateSection(MainSection.SETTINGS) }
        )
    }

    if (showPinAppPicker) {
        PinAppPickerDialog(
            apps = state.allApps.filterNot { it.packageName in prefs.hiddenPackages },
            pinnedPackages = prefs.homePinnedApps
                .filter { it.pageIndex == state.currentHomePage }
                .map { it.packageName }
                .toSet(),
            pageIndex = state.currentHomePage,
            onTogglePin = onTogglePinToPage,
            onDismiss = { showPinAppPicker = false }
        )
    }
}

@Composable
private fun DefaultHomeBanner(
    onSetDefault: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalKaliPalette.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = palette.graphiteElevated,
        border = BorderStroke(1.dp, palette.primaryAccent.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "KALI NEXUS is not default Home",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp),
                    color = palette.textPrimary
                )
                Text(
                    text = "Set as default launcher to bind the Home button",
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.5.sp),
                    color = palette.textSecondary
                )
            }
            TextButton(onClick = onSetDefault) {
                Text("Set Default", color = palette.primaryAccent)
            }
        }
    }
}

@Composable
private fun ClockAndWeatherHeader(
    nowMillis: Long,
    use24Hour: Boolean,
    showSeconds: Boolean,
    clockSizeSp: Int,
    showWeather: Boolean,
    weather: com.kalinexus.launcher.model.WeatherState,
    onRefreshWeather: () -> Unit
) {
    val palette = LocalKaliPalette.current
    val timePattern = remember(use24Hour, showSeconds) {
        when {
            use24Hour && showSeconds -> "HH:mm:ss"
            use24Hour -> "HH:mm"
            showSeconds -> "hh:mm:ss a"
            else -> "hh:mm a"
        }
    }
    val timeText = remember(nowMillis, timePattern) {
        SimpleDateFormat(timePattern, Locale.getDefault()).format(Date(nowMillis))
    }
    val dateText = remember(nowMillis) {
        SimpleDateFormat("EEEE · dd MMM yyyy", Locale.getDefault()).format(Date(nowMillis))
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = timeText,
                style = MaterialTheme.typography.displayLarge.copy(fontSize = clockSizeSp.sp),
                color = palette.textPrimary,
                maxLines = 1
            )
            Text(
                text = dateText,
                style = MaterialTheme.typography.labelMedium,
                color = palette.primaryAccent
            )
        }

        if (showWeather) {
            CyberSurfaceCard(
                modifier = Modifier
                    .padding(top = 6.dp)
                    .clickable(onClick = onRefreshWeather)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (weather.isLiveData) {
                            Icons.Outlined.WbSunny
                        } else {
                            Icons.Outlined.CloudOff
                        },
                        contentDescription = "Weather",
                        tint = palette.primaryAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (weather.temperatureCelsius != null) {
                            String.format(Locale.US, "%.1f°C", weather.temperatureCelsius)
                        } else {
                            "--°C"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary
                    )
                    if (weather.isLiveData) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Outlined.Refresh,
                            contentDescription = "Refresh Weather",
                            tint = palette.textMuted,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = weather.conditionLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = weather.locationLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun HomeTelemetryStrip(
    state: LauncherUiState,
    onOpenSystem: () -> Unit
) {
    val palette = LocalKaliPalette.current
    val tel = state.telemetry

    CyberSurfaceCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenSystem)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TelemetryMiniCell(
                icon = if (tel.isCharging) Icons.Outlined.BatteryChargingFull else Icons.Outlined.BatteryStd,
                label = "PWR",
                value = "${tel.batteryPercent}%",
                tint = if (tel.batteryPercent <= 15 && !tel.isCharging) palette.alertRed else palette.primaryAccent
            )
            TelemetryMiniCell(
                icon = Icons.Outlined.Memory,
                label = "RAM FREE",
                value = DeviceTelemetryProvider.formatBytesToGb(tel.availRamBytes),
                tint = palette.primaryAccent
            )
            TelemetryMiniCell(
                icon = Icons.Outlined.Storage,
                label = "DISK FREE",
                value = DeviceTelemetryProvider.formatBytesToGb(tel.availStorageBytes),
                tint = palette.primaryAccent
            )
            TelemetryMiniCell(
                icon = if (tel.networkConnected) Icons.Outlined.Wifi else Icons.Outlined.WifiOff,
                label = "NET",
                value = tel.networkType,
                tint = if (tel.networkConnected) palette.nominalGreen else palette.textMuted
            )
        }
    }
}

@Composable
private fun TelemetryMiniCell(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    tint: Color
) {
    val palette = LocalKaliPalette.current
    Column(horizontalAlignment = Alignment.Start) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = palette.textMuted
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = palette.textPrimary,
            maxLines = 1
        )
    }
}

@Composable
private fun HomeCustomizationDialog(
    currentColumns: Int,
    currentRows: Int,
    showTelemetryStrip: Boolean,
    onDismiss: () -> Unit,
    onPinApps: () -> Unit,
    onOpenWallpapers: () -> Unit,
    onSetGrid: (Int, Int) -> Unit,
    onToggleTelemetry: (Boolean) -> Unit,
    onOpenSettings: () -> Unit
) {
    val palette = LocalKaliPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.graphiteSurface,
        title = {
            Text("Home Workspace Controls", color = palette.textPrimary)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MenuDialogItem(Icons.Outlined.Add, "Pin / Unpin Apps on This Page", onPinApps)
                MenuDialogItem(Icons.Outlined.Wallpaper, "Wallpaper & Theme Presets", onOpenWallpapers)
                MenuDialogItem(
                    Icons.Outlined.GridView,
                    "Toggle Grid Columns (Current: ${currentColumns}x$currentRows)"
                ) {
                    val nextCols = if (currentColumns == 4) 5 else 4
                    onSetGrid(nextCols, currentRows)
                    onDismiss()
                }
                MenuDialogItem(
                    Icons.Outlined.Memory,
                    if (showTelemetryStrip) "Hide Home Telemetry Strip" else "Show Home Telemetry Strip"
                ) {
                    onToggleTelemetry(!showTelemetryStrip)
                    onDismiss()
                }
                MenuDialogItem(Icons.Outlined.Settings, "All Launcher Settings", onOpenSettings)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = palette.primaryAccent)
            }
        }
    )
}

@Composable
private fun MenuDialogItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    val palette = LocalKaliPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
    }
}

@Composable
private fun PinAppPickerDialog(
    apps: List<InstalledApp>,
    pinnedPackages: Set<String>,
    pageIndex: Int,
    onTogglePin: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalKaliPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.graphiteSurface,
        title = {
            Text("Pin Apps to Page ${pageIndex + 1}", color = palette.textPrimary)
        },
        text = {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.height(340.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(apps, key = { it.packageName }) { app ->
                    val pinned = app.packageName in pinnedPackages
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (pinned) palette.primaryAccent.copy(alpha = 0.16f)
                                else palette.graphiteDeep
                            )
                            .border(
                                1.dp,
                                if (pinned) palette.primaryAccent else palette.hairlineBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { onTogglePin(app.packageName) }
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = app.label,
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                            color = palette.textPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (pinned) "PINNED" else "TAP",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (pinned) palette.primaryAccent else palette.textMuted
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = palette.primaryAccent)
            }
        }
    )
}
