package com.kalinexus.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.kalinexus.launcher.model.CyberThemePreset

@Immutable
data class KaliNexusPalette(
    val voidBlack: Color = Color(0xFF040608),
    val graphiteDeep: Color = Color(0xFF0A0E14),
    val graphiteSurface: Color = Color(0xFF10161F),
    val graphiteElevated: Color = Color(0xFF17202C),
    val hairlineBorder: Color = Color(0xFF1F2B3B),
    val primaryAccent: Color = Color(0xFF00E5FF),
    val secondaryAccent: Color = Color(0xFF00A3FF),
    val textPrimary: Color = Color(0xFFF1F6FA),
    val textSecondary: Color = Color(0xFF93A4B8),
    val textMuted: Color = Color(0xFF5D6F84),
    val nominalGreen: Color = Color(0xFF10B981),
    val warningAmber: Color = Color(0xFFF59E0B),
    val alertRed: Color = Color(0xFFEF4444)
)

val LocalKaliPalette = staticCompositionLocalOf { KaliNexusPalette() }

@Composable
fun KaliNexusTheme(
    preset: CyberThemePreset = CyberThemePreset.CYBER_CYAN,
    content: @Composable () -> Unit
) {
    val primary = Color(preset.primaryHex)
    val secondary = Color(preset.secondaryHex)

    val palette = KaliNexusPalette(
        primaryAccent = primary,
        secondaryAccent = secondary
    )

    val materialScheme = darkColorScheme(
        primary = primary,
        onPrimary = Color(0xFF03070B),
        secondary = secondary,
        onSecondary = Color(0xFF03070B),
        background = palette.voidBlack,
        onBackground = palette.textPrimary,
        surface = palette.graphiteSurface,
        onSurface = palette.textPrimary,
        surfaceVariant = palette.graphiteElevated,
        onSurfaceVariant = palette.textSecondary,
        outline = palette.hairlineBorder,
        error = palette.alertRed
    )

    CompositionLocalProvider(LocalKaliPalette provides palette) {
        MaterialTheme(
            colorScheme = materialScheme,
            typography = KaliNexusTypography,
            content = content
        )
    }
}
