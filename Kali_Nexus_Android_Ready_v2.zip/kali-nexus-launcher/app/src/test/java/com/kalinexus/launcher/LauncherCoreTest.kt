package com.kalinexus.launcher

import com.kalinexus.launcher.data.BackupManager
import com.kalinexus.launcher.model.AppSortOrder
import com.kalinexus.launcher.model.CyberThemePreset
import com.kalinexus.launcher.model.InstalledApp
import com.kalinexus.launcher.model.LauncherPreferences
import com.kalinexus.launcher.system.AppDiscoveryManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LauncherCoreTest {

    private fun sampleApps(): List<InstalledApp> = listOf(
        InstalledApp("com.example.zeta", "ZetaActivity", "Zeta Notes", false, false, 1L, 1L),
        InstalledApp("com.example.alpha", "AlphaActivity", "Alpha Mail", false, false, 1L, 1L),
        InstalledApp("com.example.hidden", "HiddenActivity", "Secret Tool", false, false, 1L, 1L),
        InstalledApp("com.android.settings", "Settings", "Settings", true, false, 1L, 1L)
    )

    @Test
    fun `filterAndSortApps excludes hidden packages and sorts alphabetically`() {
        val result = AppDiscoveryManager.filterAndSortApps(
            apps = sampleApps(),
            hiddenPackages = setOf("com.example.hidden"),
            query = "",
            searchPackageNames = false,
            sortOrder = AppSortOrder.ALPHA_ASC
        )
        assertEquals(listOf("Alpha Mail", "Settings", "Zeta Notes"), result.map { it.label })
    }

    @Test
    fun `filterAndSortApps matches package name only when enabled`() {
        val apps = sampleApps()
        val labelOnly = AppDiscoveryManager.filterAndSortApps(
            apps = apps,
            hiddenPackages = emptySet(),
            query = "com.android",
            searchPackageNames = false,
            sortOrder = AppSortOrder.ALPHA_ASC
        )
        assertTrue(labelOnly.isEmpty())

        val withPkg = AppDiscoveryManager.filterAndSortApps(
            apps = apps,
            hiddenPackages = emptySet(),
            query = "com.android",
            searchPackageNames = true,
            sortOrder = AppSortOrder.ALPHA_ASC
        )
        assertEquals(1, withPkg.size)
        assertEquals("Settings", withPkg.first().label)
    }

    @Test
    fun `backup export and import roundtrip preserves preferences and clamps bounds`() {
        val original = LauncherPreferences(
            themePreset = CyberThemePreset.ELECTRIC_COBALT,
            gridColumns = 5,
            dockCount = 6,
            favoritePackages = setOf("com.example.alpha"),
            hiddenPackages = setOf("com.example.hidden")
        )
        val exported = BackupManager.exportToJson(original)
        val restored = BackupManager.importFromJson(exported)
        assertTrue(restored.isSuccess)
        assertEquals(original, restored.getOrThrow())
    }
}
