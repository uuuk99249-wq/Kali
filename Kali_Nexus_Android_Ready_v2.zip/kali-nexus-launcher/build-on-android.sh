#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle command not found. Complete AndroidIDE build-tools setup first."
  exit 1
fi
if [ ! -f "./gradlew" ]; then
  echo "Generating Gradle 8.9 wrapper..."
  gradle wrapper --gradle-version 8.9
fi
echo "Building KALI NEXUS debug APK..."
./gradlew --no-daemon assembleDebug
echo
echo "Build complete. APK location:"
echo "app/build/outputs/apk/debug/app-debug.apk"
